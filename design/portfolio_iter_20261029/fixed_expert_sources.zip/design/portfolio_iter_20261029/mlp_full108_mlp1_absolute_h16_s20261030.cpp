// Single-file C++14 scheduler. Uses only SystemState, next_op and own history.
// Flags are for reproducible local ablations; the evaluator uses no arguments.
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include <cmath>

class MySpillScheduler final : public SpillScheduler {
    // Inference sees only public state and scheduler-owned observations.
    int policy_mode_=-1,forced_next_=-1,selected_expert_=7;
    std::array<double,512> gds_{};double gds_clock_=0;
    uint64_t choices_=0,inferences_=0;
    static double bounded(double x){return std::max(0.0,std::min(1.0,x));}
    float cheapMlpTargetHeat(const SystemState& s,int o,int p) const {int id=o*s.num_partitions+p;uint64_t now=tick(s),age=now>last_[id]?now-last_[id]:0;double h=double(heat_[id])/(1.0+double(age)/64.0);return float(h/(1+h));}
static int cheapMlpDecision(const std::array<float,20>& numeric,int previous) {
    static constexpr float w1[16][20]={{4.38854122f,-2.45738125f,-2.34795737f,-3.85070586f,-0.478970587f,-2.64104295f,-0.323450804f,-0.359608084f,1.89218867f,-1.33020723f,-2.51538658f,-0.125591606f,1.26114738f,1.64598072f,2.58229017f,-0.0450221933f,0.440299243f,-1.49054074f,-2.69479728f,-1.59080279f},{6.63688946f,1.30662656f,-0.0525663756f,-4.51948214f,-3.5334549f,-0.494360209f,1.42831612f,-1.94044268f,-0.741387546f,-1.21441233f,-0.629266143f,-0.0724483579f,1.98380399f,2.30398703f,0.819651961f,2.23859477f,0.561630011f,0.261318564f,0.12949568f,1.03144145f},{1.34320378f,-1.30378282f,1.64288712f,-4.25412893f,-3.41634512f,-0.0793472975f,2.32619524f,-1.10253012f,1.74239576f,-0.191771433f,-3.31118131f,0.931067884f,-0.0695003271f,0.618623972f,1.7740252f,2.82672882f,0.810466766f,1.86189342f,-0.243222475f,1.32005596f},{5.20021486f,0.983641982f,1.05237925f,-3.78517532f,-0.496142864f,-1.03233898f,1.10618293f,0.34621501f,2.93412137f,-2.23551655f,-2.20180249f,0.0654760301f,-0.0155500174f,-0.121892162f,-3.47577667f,-0.0174543597f,-2.0525651f,-2.37567735f,-0.875420034f,2.62007046f},{1.19773173f,0.428168833f,0.0136145828f,0.312646151f,2.02835321f,2.32821584f,-0.708305538f,2.10958815f,2.83371949f,-0.864943802f,0.282944888f,-1.51289463f,-0.755117774f,-1.1614815f,-1.78821325f,0.195277154f,1.69753706f,-0.524676979f,-0.441145629f,-2.64621115f},{0.352726251f,0.252462059f,-3.77911806f,-1.77284455f,2.58833456f,2.29858541f,-0.168029532f,-0.373763889f,-4.47547579f,2.20460963f,-0.475566149f,-0.347572625f,0.711805344f,-0.653105736f,0.184015065f,0.346962154f,-0.129103824f,-1.72159278f,-2.48536777f,0.735699713f},{3.66089058f,1.43655241f,6.32271767f,-1.27429903f,0.459548384f,-0.0371527597f,-1.83893347f,1.87352931f,-2.58483768f,2.77995229f,-1.04591811f,-0.209518999f,-1.64068675f,1.85309696f,-1.46987844f,-3.959234f,-2.57705188f,-0.935079038f,2.53503942f,-2.1527698f},{3.14905715f,-3.48687315f,-5.04118872f,-3.17203164f,3.14681888f,1.48558295f,-2.72178197f,2.07433081f,2.88045907f,-2.77460623f,-2.32198334f,1.01184797f,-1.25742137f,-0.211641058f,-0.883500457f,-1.80998862f,0.228100657f,-1.36939335f,-1.91362393f,-3.40854692f},{-3.75021172f,1.88307095f,-0.513680279f,5.66969919f,-1.7530154f,-0.1617883f,-1.72244811f,-0.240952894f,1.15610242f,-0.665827155f,4.51371336f,-2.10901737f,2.17291713f,-1.8845129f,-1.63764822f,-0.0237819757f,0.420339525f,1.22931504f,1.76257956f,-2.22283554f},{-2.07287073f,-0.329153657f,-8.21324825f,4.15312862f,1.00985968f,-1.63634515f,-4.1451149f,2.31036067f,3.57701635f,-2.04582405f,-2.95948696f,-0.16166757f,1.10015345f,1.2867552f,3.28259873f,-0.0302789025f,0.785092533f,-2.7862978f,-0.79554534f,1.6783402f},{-6.05239773f,0.445040762f,-7.86685085f,3.25554943f,0.705041111f,0.245379388f,1.74056447f,-0.081481792f,0.147687778f,0.681272805f,0.820546687f,-1.45648193f,-0.398595005f,1.0516876f,-2.30748653f,-1.18253398f,1.40287995f,-0.565695047f,1.00032341f,-0.0981074795f},{-1.61213136f,-3.48185062f,-6.7989316f,-2.93417788f,-1.58912575f,-0.885338724f,0.13815935f,3.27064562f,1.08558416f,-1.52635896f,1.22441888f,-1.74241841f,1.65765643f,-0.147453293f,-0.113722287f,0.829148769f,0.565949738f,0.592142999f,0.926362276f,2.87103677f},{-5.02037573f,0.838047862f,-2.9334681f,5.2833457f,0.50410372f,1.10348463f,-2.32020998f,2.37724519f,2.66154432f,-4.0240097f,0.118780248f,-2.16954899f,2.42639828f,0.530248821f,-2.42841005f,0.709517181f,1.24760127f,-0.320691228f,-0.395621181f,-4.0533433f},{-1.21384609f,-2.09918332f,-3.4784286f,-1.73779964f,1.42404568f,0.627596915f,3.31783509f,-3.64981294f,0.197648436f,-0.0476925559f,-0.765603721f,0.207053244f,1.09190726f,0.414642245f,-0.493513197f,-1.01483202f,2.45870972f,0.934588492f,-0.177375332f,4.47169971f},{6.43838549f,-0.394708663f,3.97480273f,-4.27796555f,-2.88363528f,-0.125209749f,-0.867081583f,0.530655026f,0.318710983f,-0.670171559f,-0.0528226644f,-0.605163157f,2.15387869f,1.74360156f,-0.0254082289f,-1.13077247f,0.301414967f,0.725640714f,0.675170124f,5.01993179f},{4.18453217f,1.96486318f,5.68784332f,-2.98842406f,-2.32841301f,-0.440506697f,0.38888061f,1.4455353f,-1.57963157f,1.69224143f,3.46850157f,-0.817742646f,0.401291609f,1.10794187f,-0.298084229f,0.825429916f,0.242388651f,0.269129962f,-2.72472429f,5.67024946f}};
    static constexpr float category[16][8]={{5.5596697e-08f,-0.395507097f,-0.0450586379f,-0.399496049f,0.267936945f,0.574862897f,-0.267001688f,-0.471094817f},{-7.21116278e-09f,0.257973164f,0.495271802f,-0.149541333f,0.0982003286f,0.789999962f,-0.00996202882f,0.185144499f},{-6.68246303e-09f,0.467771381f,0.837000489f,0.247936338f,-1.03871226f,1.19725704f,0.648389757f,0.158199847f},{8.84667031e-07f,0.590220928f,1.00322342f,-0.508113205f,-0.775084317f,0.490959048f,0.239672512f,-0.149049789f},{-1.41311233e-07f,-0.434247017f,0.00359066459f,-0.364724964f,-1.3080399f,0.50298816f,0.314759374f,-0.450288028f},{-8.52239612e-09f,-0.684426963f,0.727012455f,-0.0488975197f,1.23993146f,-1.58067572f,-0.30714944f,0.718719065f},{3.61344682e-05f,0.840328157f,0.781811535f,-0.34459579f,0.335358143f,-0.14638947f,-0.123968415f,0.113729499f},{7.91236765e-09f,-0.0825125426f,-0.288738191f,0.860870361f,0.952951908f,-0.124255702f,0.122746259f,-0.167759418f},{-4.61616551e-10f,-0.00199208851f,0.905817211f,0.660041392f,0.27732271f,0.178717166f,-0.101335108f,-0.430084199f},{2.07969308e-09f,-0.953209341f,0.704046428f,0.132009223f,0.22909528f,0.625440955f,0.779742837f,0.0103265429f},{-0.00104504311f,0.377372742f,0.356345236f,0.118452169f,-0.13202168f,-1.25287807f,1.11252797f,0.657308877f},{-4.27938218e-09f,0.716758549f,-0.889333367f,-0.0618311912f,1.03009045f,-0.351494282f,-0.390487552f,-0.358785063f},{-8.04633782e-09f,0.220355242f,1.19279492f,0.83939445f,-1.40772164f,0.108335309f,0.040564958f,-0.00762089901f},{0.00106877356f,-0.227818549f,-0.387325853f,0.0954245627f,-0.341676474f,-0.0993401036f,0.505367458f,0.505467951f},{-0.000246912037f,0.569074333f,0.457880795f,-0.335959554f,-0.180837363f,0.317668438f,-0.286381871f,-0.357916683f},{-0.00118588691f,0.0608662814f,0.598235369f,1.75739026f,0.761762321f,1.20763421f,-0.870311737f,0.181426406f}};
    static constexpr float b1[16]={-3.09077287f,-6.07459688f,-2.5624094f,-2.73305774f,-5.05822515f,4.58804035f,-0.846178889f,-3.97361851f,2.60017323f,-2.88974881f,5.75032425f,-1.44410634f,-0.983653545f,1.41020334f,-9.00197411f,-3.8925879f};
    static constexpr float w2[8][16]={{-0.975150883f,-0.300154388f,-0.716607511f,-0.852441609f,-0.179212183f,-0.491645753f,0.491207123f,-0.692321002f,-0.705946922f,0.541061044f,-0.0162063353f,-0.697534204f,-0.110553645f,0.0107642869f,-0.516731858f,-0.35438925f},{0.510469377f,0.879324198f,1.27690089f,0.521962881f,-1.09486282f,-0.392046779f,-0.46921441f,-0.184522897f,-0.716458559f,0.13147974f,-0.736950815f,0.486930788f,-0.674248874f,0.11020983f,0.813654959f,0.429212511f},{0.367190123f,-0.61672157f,-1.87783515f,-0.177591905f,0.232890666f,0.49107039f,-0.258112758f,0.352709532f,0.663343012f,0.609840155f,0.591285348f,0.0346918441f,0.816193521f,0.207950443f,-0.465001196f,-1.84221077f},{-0.198567271f,-0.262881875f,-0.283928186f,-0.592175245f,-0.239492744f,-0.0345410109f,-0.166662648f,-0.281190246f,0.0612203442f,-0.678886056f,-0.121548414f,-0.0258168783f,0.230595976f,-0.453432858f,0.122964762f,-0.0910955593f},{-0.677861512f,0.261777163f,0.701092064f,-1.03717566f,-0.215188742f,-0.368865639f,-0.777106524f,-1.02085912f,0.657019556f,-0.695063233f,-0.0907390788f,0.431474239f,0.411199689f,-0.58030951f,0.0120057212f,0.4860771f},{-0.740819752f,-0.25902164f,-0.569738507f,-0.238552138f,0.220855996f,0.393132985f,0.176379859f,0.103274412f,-0.222073421f,-0.779394627f,0.156661049f,-0.413482904f,-0.395005375f,0.155821159f,-0.861622691f,-0.179063261f},{-0.162102804f,-0.231673062f,-0.195487216f,-0.416284055f,-0.325707436f,-0.557584703f,-0.612411737f,-0.614126861f,0.28447023f,-0.356032163f,-0.242799401f,-0.0952044278f,-0.487881422f,-0.252444208f,-0.159570858f,0.0633648932f},{-0.861958981f,-1.33096898f,0.456554651f,0.35065946f,1.01653218f,-0.0166702289f,0.809913158f,0.301781029f,-0.256953716f,-1.18457484f,0.114460163f,-1.50661397f,-0.86274147f,-1.12892914f,-0.844352841f,0.830365479f}};
    static constexpr float b2[8]={0.480234116f,-0.0368821211f,-0.0174013916f,-0.266556263f,-0.33703503f,-0.187534407f,-0.419789821f,0.338182598f};
    if(previous<0||previous>=8)previous=7;
    std::array<float,16> activation;
    for(int j=0;j<16;++j){float value=b1[j];
        for(int i=0;i<20;++i){float product=w1[j][i]*numeric[i];value=float(value+product);}
        value=float(value+category[j][previous]);activation[j]=value>0.0f?value:0.0f;}
    int best=0;float best_value=0.0f;
    for(int e=0;e<8;++e){float value=b2[e];
        for(int j=0;j<16;++j){float product=w2[e][j]*activation[j];value=float(value+product);}
        if(e==0||value>best_value){best=e;best_value=value;}}return best;
}
int route(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
    const std::array<float,20> numeric={{float(double(s.memory_used)/double(s.memory_limit)),float(double(bytes)/double(s.memory_limit)),float(std::max(0.0,double(bytes)-double(s.memory_limit-s.memory_used))/double(s.memory_limit)),float(double(s.memory_limit-s.memory_used)/double(s.memory_limit)),float(s.operators.size()/8.0),float(s.num_partitions/64.0),float(build),float(s.operators[o].phase==Phase::PROBE),float(s.next_op.type=="PROBE"),float(s.next_op.type=="INSERT"),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size/double(s.memory_limit)):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].in_memory):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.next_op.op_id==o):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float((build?s.operators[o].partitions[p].data_size+double(bytes):double(bytes))+s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size<=double(s.memory_limit)):0.0f),float(s.write_bandwidth/10000.0),float(s.read_bandwidth/10000.0),float(double(s.miss_count)/double(std::max(uint64_t(1),tick(s)))),float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),tick(s)-epoch_)))),cheapMlpTargetHeat(s,o,p),float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),tick(s)-epoch_))))}};
    return cheapMlpDecision(numeric,selected_expert_);
}
#ifdef PORTFOLIO_AUDIT
int routeReference(const std::array<float,32>& x) const {
    const std::array<float,20> numeric={{x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[17],x[18],x[19],x[20],x[21],x[22],x[23],x[24],x[25],x[26],x[27],x[29]}};
    int previous=int(double(x[30])*7.0+0.5);return cheapMlpDecision(numeric,previous);
}
#endif

    int activeRule(bool build) const {
        static const int rules[8]={0,8,3,6,4,9,4,4};
        return selected_expert_==7?(build?0:rule_):((selected_expert_==6&&build)?0:rules[selected_expert_]);
    }
    int creditRule() const {int r=activeRule(false);return (r==3||r==4||r==6)?r:-1;}
    void choose(const SystemState& s,int o,int p,bool build,int64_t bytes) {
        if(forced_next_>=0){selected_expert_=forced_next_;forced_next_=-1;}
        else if(policy_mode_>=0)selected_expert_=policy_mode_;
        else if(policy_mode_==-2)selected_expert_=int((tick(s)*6364136223846793005ULL+choices_*1442695040888963407ULL)%8);
        else {int next_expert=route(s,o,p,build,bytes);
#ifdef PORTFOLIO_AUDIT
if(next_expert!=routeReference(features(s,o,p,build,bytes)))throw std::runtime_error("route feature mismatch");
#endif
selected_expert_=next_expert;++inferences_;}
        ++choices_;
    }
    struct Victim { int o,p,id; int64_t bytes; double value,key; };
    struct Ghost { uint64_t at=0; int rule=-1; bool credited=false; int requester=-1; bool avoidable_cross=false; };
    int flags_,rule_=4,options_;
    uint64_t load_demands_=0,compensated_misses_=0;
    bool spilled_=false,first_miss_=false;
    std::array<uint64_t,512> last_{};
    std::array<float,512> heat_{};
    std::array<Ghost,512> ghost_{};
    std::array<double,8> op_heat_{},budget_{};
    std::array<uint64_t,8> op_last_{};
    std::array<double,7> loss_{};
    std::array<unsigned,7> trials_{};
    std::array<double,64> interference_{};
    std::array<uint64_t,64> interference_at_{};
    double interference(int source,int victim,uint64_t now) const {
        int i=source*8+victim;uint64_t age=now>interference_at_[i]?now-interference_at_[i]:0;
        return interference_[i]/(1.0+double(age)/256.0);
    }

    uint64_t epoch_=0,epoch_miss_=0,switched_at_=0,returns_=0,return_base_=0;
    int phase_mask_=-1;
    static uint64_t tick(const SystemState& s) {return uint64_t(s.hit_count+s.miss_count);}
    static bool probeNext(const SystemState& s) {return s.next_op.type=="PROBE";}
    static bool less(const Victim& a,const Victim& b) {
        if(a.key!=b.key)return a.key<b.key;
        if(a.bytes!=b.bytes)return a.bytes>b.bytes;
        return a.id>b.id;
    }
    static double clip(double x,double a,double b) {return std::max(a,std::min(b,x));}
    void observe(int id,int o,uint64_t now) {
        if(last_[id]==now)return;
        uint64_t age=now>last_[id]?now-last_[id]:0;
        heat_[id]=float(double(heat_[id])/(1.0+double(age)/64.0)+1.0);last_[id]=now;
        age=now>op_last_[o]?now-op_last_[o]:0;
        op_heat_[o]=op_heat_[o]/(1.0+double(age)/128.0)+1.0;op_last_[o]=now;
    }
    void observeNext(const SystemState& s) {
        if(!probeNext(s))return;
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
        if(s.operators[o].phase==Phase::PROBE){observe(o*s.num_partitions+p,o,tick(s)+1);
            double z=double(s.operators[o].partitions[p].data_size);
            gds_[o*s.num_partitions+p]=gds_clock_+(z/s.write_bandwidth+z/s.read_bandwidth+1.0)/std::max(1.0,z);}

    }
    void credit(int rule,double loss) {
        if(rule<0)return;
        loss_[rule]=trials_[rule]?0.875*loss_[rule]+0.125*loss:loss;
        ++trials_[rule];
    }
    void loaded(const SystemState& s,int o,int p) {
        int gid=o*s.num_partitions+p;double gs=double(s.operators[o].partitions[p].data_size);
        gds_[gid]=gds_clock_+(gs/s.write_bandwidth+gs/s.read_bandwidth+1.0)/std::max(1.0,gs);
        Ghost& g=ghost_[gid];
        if(!g.at)return;
        uint64_t age=tick(s)+1-g.at,width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        if(age<=width){if(g.rule>=0 || !(flags_&64))++returns_;if(!g.credited)credit(g.rule,1.0);}
        else if(!g.credited)credit(g.rule,0.0);
        if((flags_&1024)&&age<=width&&g.avoidable_cross) {
            int edge=g.requester*8+o;
            double bytes=double(s.operators[o].partitions[p].data_size);
            interference_[edge]=interference(g.requester,o,tick(s))+bytes/s.write_bandwidth+bytes/s.read_bandwidth+1.0;
            interference_at_[edge]=tick(s);++interference_returns;
        }
        g=Ghost();
    }
    void remember(const SystemState& s,const std::vector<Action>& a,int cause) {
        for(const auto& x:a) {
            if(x.type==Action::SPILL) {
                int id=x.op_id*s.num_partitions+x.partition_id;
                if(selected_expert_==5)gds_clock_=std::max(gds_clock_,gds_[id]);
                gds_[id]=0;
                ghost_[id].at=tick(s)+1;
                // If victim and demand target cannot coexist, eviction is forced;
                // do not treat its return as evidence against a discretionary rule.
                ghost_[id].rule=((flags_&64)&&cause>=0&&s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_>s.memory_limit)?-1:cause;
                ghost_[id].credited=false;ghost_[id].requester=requester_;
                ghost_[id].avoidable_cross=requester_>=0&&requester_!=x.op_id&&s.operators[x.op_id].phase==Phase::PROBE&&
                    s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_<=s.memory_limit;
                if(x.op_id!=requester_)++cross_spills;
            } else loaded(s,x.op_id,x.partition_id);
        }
    }
    int requester_=-1;int64_t demand_size_=0;
    void allocate(const SystemState& s) {
        int k=int(s.operators.size());uint64_t now=tick(s);
        std::array<double,8> cap{},w{};std::array<bool,8> done{};
        for(const auto& op:s.operators) {
            for(const auto& x:op.partitions)cap[op.op_id]+=double(x.data_size);
            int o=op.op_id;uint64_t age=now>op_last_[o]?now-op_last_[o]:0;
            double h=op_heat_[o]/(1.0+double(age)/128.0);
            w[o]=(op.phase==Phase::PROBE?1.0:0.25)*(1.0+h);budget_[o]=0;
        }
        double remaining=double(s.memory_limit);
        for(int pass=0;pass<=k;++pass) {
            double sw=0;for(int o=0;o<k;++o)if(!done[o])sw+=w[o];
            if(sw<=0)break;
            bool capped=false;
            for(int o=0;o<k;++o)if(!done[o] && cap[o]<=remaining*w[o]/sw) {
                budget_[o]=cap[o];done[o]=true;capped=true;
            }
            if(!capped){for(int o=0;o<k;++o)if(!done[o])budget_[o]=remaining*w[o]/sw;break;}
            remaining=double(s.memory_limit);for(int o=0;o<k;++o)if(done[o])remaining-=budget_[o];
        }
        ++allocations;
    }
    void adapt(const SystemState& s,int o,int p) {
        uint64_t now=tick(s);int mask=phase_mask_;
        if(mask!=((1<<int(s.operators.size()))-1)){mask=0;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)mask|=1<<op.op_id;}
        uint64_t observed_misses=(options_&8)?((options_&64)?uint64_t(s.miss_count)+compensated_misses_:load_demands_):uint64_t(s.miss_count);
        bool first=!first_miss_,urgent=returns_-return_base_>=3;
        if(!first && mask==phase_mask_ && now-epoch_<128 && observed_misses-epoch_miss_<32 && !urgent)return;
        uint64_t width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        for(int i=0,q=int(s.operators.size())*s.num_partitions;i<q;++i){auto& g=ghost_[i];if(g.at && !g.credited && now+1-g.at>width){credit(g.rule,0.0);g.credited=true;}}
        if(first) {
            first_miss_=true;
            if(flags_&32) {
                double a=double(s.operators[o].partitions[p].data_size)/s.memory_limit,b=-1;
                if(probeNext(s))b=double(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size)/s.memory_limit;
                rule_=a<=.125?(b<=.0013453512706539845?3:4):(s.operators.size()<=1?4:3);
            }
        } else if(flags_&4) {
            double rate=std::min(1.0,double(observed_misses-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_)));
            int desired=(flags_&256)?rule_:4;
            // Positive evidence for a repeat working set favours heat/byte;
            // sustained misses without quick returns favour observed recency.
            if(urgent && rate>.12)desired=6;
            else if(rate>.65 && !urgent && !(flags_&128))desired=3;
            if((flags_&256)&&desired==rule_&&rule_!=4&&rate>.30&&loss_[rule_]>.50)desired=4;
            double best=loss_[desired]+(trials_[desired]?0.0:.12);
            for(int r:{4,3,6})if(trials_[r]>=4 && loss_[r]+.12<best){desired=r;best=loss_[r];}
            uint64_t dwell=urgent?8:64;
            if(desired!=rule_ && now-switched_at_>=dwell) {
                // Hysteresis prevents a tiny sampled advantage triggering a switch.
                if(urgent || desired==4 || !trials_[rule_] || loss_[rule_]>best+.08 || rate>.65) {
                    rule_=desired;switched_at_=now;++switches;
                }
            }
        }
        epoch_=now;epoch_miss_=observed_misses;return_base_=returns_;phase_mask_=mask;++epochs;
        if(flags_&8)allocate(s);
    }
    std::vector<Action> plan(const SystemState& s,int64_t need,int to,int tp,bool build,int po=-1,int pp=-1) {
        int64_t deficit=need-(s.memory_limit-s.memory_used);if(deficit<=0)return {};
        int rule=activeRule(build);
        std::array<double,8> used{},factor{};factor.fill(1.0);
        bool quota=(selected_expert_==6||selected_expert_==7);
        if(build&&(options_&4)){bool has_probe=false;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)has_probe=true;if(!has_probe)quota=false;}
        if(quota) {
            if(build || !allocations)allocate(s);
            for(const auto& op:s.operators)for(const auto& x:op.partitions)if(x.in_memory)used[op.op_id]+=double(x.data_size);
            double pad=double(s.memory_limit)/(32.0*s.operators.size());
            for(unsigned o=0;o<s.operators.size();++o)factor[o]=clip((budget_[o]+pad)/(used[o]+pad),.5,2.0);
        }
        std::array<Victim,512> c;int n=0,best=-1;uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            int o=op.op_id,p=x.partition_id,id=o*s.num_partitions+p;
            if(!x.in_memory||x.data_size<=0||(o==to&&p==tp)||(o==po&&p==pp))continue;
            double v=0,key=-double(x.data_size)/factor[o];
            if(rule==8){v=double(x.data_size)/s.write_bandwidth;key=double(x.data_size);}
            else if(rule==9){
                if(gds_[id]==0)gds_[id]=gds_clock_+(double(x.data_size)/s.write_bandwidth+double(x.data_size)/s.read_bandwidth+1.0)/double(x.data_size);
                key=gds_[id];
            }
            else if(rule==4) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0),q=.15+.70*h/(1.0+h);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)q=1.0;
                if(op.phase==Phase::BUILD)q*=.35;
                v=(double(x.data_size)/s.write_bandwidth+q*(double(x.data_size)/s.read_bandwidth+32.0))*factor[o];
                key=v/double(x.data_size);
            } else if(rule==3)key=(double(last_[id])+1.0)*factor[o];
            else if(rule==6) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0);
                key=(1.0+h)*factor[o]/double(x.data_size);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)key*=16.0;
            }
            if((flags_&1024)&&requester_>=0&&requester_!=o) {
                double unit=double(s.memory_limit)*(1.0/s.write_bandwidth+1.0/s.read_bandwidth)+1.0;
                double charge=1.0+std::min(3.0,interference(requester_,o,now)/unit);
                if(rule==0)key/=charge;else {key*=charge;v*=charge;}
            }
            c[n]={o,p,id,x.data_size,v,key};if(best<0||less(c[n],c[best]))best=n;++n;
        }
        // Every resident x with size(x)>M-locked is infeasible beside the
        // partitions which this request must retain. Such x must be spilled.
        // If forced victims cover the deficit, this set attains the unavoidable
        // immediate-write lower bound. No future-Score optimality is claimed.
        int64_t locked=build?s.operators[to].partitions[tp].data_size+need:need;
        if(po>=0&&!(po==to&&pp==tp)&&s.operators[po].partitions[pp].in_memory)
            locked+=s.operators[po].partitions[pp].data_size;
        if(locked<=s.memory_limit){
            int64_t forced_bytes=0;
            for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)forced_bytes+=c[i].bytes;
            if(forced_bytes>=deficit){
                std::vector<Action> a;a.reserve(n+2);
                for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                return a;
            }
        }
        // Exact minimum immediate write bytes for <=10 eligible candidates.
        // Larger instances use size order + covering singleton, without an optimality claim.
        if(rule==8&&n<=10){
            int64_t best_bytes=INT64_MAX;unsigned best_mask=0;
            std::array<int64_t,1024> sums;sums[0]=0;unsigned count=1;
            for(int i=0;i<n;++i){
                for(unsigned j=0;j<count;++j){unsigned mask=count+j;sums[mask]=sums[j]+c[i].bytes;
                    if(sums[mask]>=deficit&&sums[mask]<best_bytes){best_bytes=sums[mask];best_mask=mask;}}
                count*=2;
            }
            std::vector<Action> a;a.reserve(n+2);
            for(int i=0;i<n;++i)if(best_mask&(1u<<i))a.emplace_back(Action::SPILL,c[i].o,c[i].p);
            return a;
        }
        // The sorted greedy prefix has length one in this case. Select the
        // same minimum-cost covering singleton in O(Q), preserving tie order.
        if((flags_&16) && best>=0 && c[best].bytes>=deficit) {
            int chosen=best;
            if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit &&
                (c[i].value<c[chosen].value || (c[i].value==c[chosen].value&&less(c[i],c[chosen]))))chosen=i;
            ++linear_plans;std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[chosen].o,c[chosen].p);return a;
        }
        // Exact shortcut for a sorted greedy prefix of length two.
        // No heuristic truncation: all covering singletons are still compared.
        if(best>=0&&c[best].bytes<deficit) {
            int second=-1;
            for(int i=0;i<n;++i)if(i!=best&&(second<0||less(c[i],c[second])))second=i;
            if(second>=0&&c[best].bytes+c[second].bytes>=deficit) {
                int64_t freed=c[best].bytes+c[second].bytes;
                double value=c[best].value+c[second].value;int single=-1;
                if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit) {
                    if(c[i].value<value){single=i;value=c[i].value;}
                    else if(single>=0&&c[i].value==value&&less(c[i],c[single]))single=i;
                }
                std::vector<Action> a;a.reserve(2+(build?0:2));
                if(single>=0)a.emplace_back(Action::SPILL,c[single].o,c[single].p);
                else {
                    for(int i:{best,second}) {
                        if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
                        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                    }
                }
                ++prefix2_plans;return a;
            }
        }
        ++sorted_plans;std::sort(c.begin(),c.begin()+n,less);
        int take=0;int64_t freed=0;double value=0;
        while(take<n&&freed<deficit){freed+=c[take].bytes;value+=c[take].value;++take;}
        if(rule==4||rule==8) {
            int single=-1;for(int i=0;i<n;++i)if(c[i].bytes>=deficit&&c[i].value<value){single=i;value=c[i].value;}
            if(single>=0){std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[single].o,c[single].p);return a;}
        }
        std::vector<Action> a;a.reserve(take+(build?0:2));
        for(int i=0;i<take;++i)if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
        return a;
    }
    static int64_t written(const SystemState& s,const std::vector<Action>& a) {
        int64_t n=0;for(const auto& x:a)if(x.type==Action::SPILL)n+=s.operators[x.op_id].partitions[x.partition_id].data_size;return n;
    }
    // Local certificate: any resident x with size(x)>M-size(B) MUST leave
    // before B can be loaded. Only prefetch when these forced victims suffice.
    bool forced(const SystemState& s,int o,int p,int64_t need,std::vector<Action>& a,int64_t freed) {
        if(!(flags_&2)||need<s.memory_limit/2)return false;
        int64_t deficit=need-(s.memory_limit-s.memory_used+freed);if(deficit<=0)return true;
        std::array<bool,512> removed{};
        for(const auto& x:a)if(x.type==Action::SPILL)removed[x.op_id*s.num_partitions+x.partition_id]=true;
        std::vector<Action> extra;int64_t sum=0;
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            if(x.in_memory&&x.data_size>s.memory_limit-need&&!removed[op.op_id*s.num_partitions+x.partition_id]&&!(op.op_id==o&&x.partition_id==p)) {
                extra.emplace_back(Action::SPILL,op.op_id,x.partition_id);sum+=x.data_size;
            }
        }
        if(sum<deficit)return false;
        a.insert(a.end(),extra.begin(),extra.end());++certified_prefetches;return true;
    }
public:

    void forceNext(int x){forced_next_=x;}
    void setMode(int x){policy_mode_=x;}
    int lastExpert() const{return selected_expert_;}
    uint64_t inferenceCount() const{return inferences_;}
    std::array<float,32> features(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
        std::array<float,32> f{};double m=double(s.memory_limit),sum=0,sq=0,mx=0,mn=m,bld=0,prb=0,own=0,total=0,own_total=0,heat=0;int nr=0;
        uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions){
            total+=x.data_size;if(op.op_id==o)own_total+=x.data_size;
            if(!x.in_memory||x.data_size<=0)continue;
            double z=double(x.data_size);sum+=z;sq+=z*z;mx=std::max(mx,z);mn=std::min(mn,z);++nr;
            if(op.phase==Phase::BUILD)bld+=z;else prb+=z;if(op.op_id==o)own+=z;
            int id=op.op_id*s.num_partitions+x.partition_id;uint64_t age=now>last_[id]?now-last_[id]:0;
            heat+=double(heat_[id])/(1.0+double(age)/64.0);
        }
        double free=double(s.memory_limit-s.memory_used),size=double(bytes),q=double(s.operators.size()*s.num_partitions);
        const auto& target=s.operators[o].partitions[p];int tid=o*s.num_partitions+p;uint64_t age=now>last_[tid]?now-last_[tid]:0;
        double h=double(heat_[tid])/(1.0+double(age)/64.0),avg=heat/std::max(1,nr);
        f[0]=float(s.memory_used/m);f[1]=float(size/m);f[2]=float(std::max(0.0,size-free)/m);f[3]=float(free/m);
        f[4]=float(s.operators.size()/8.0);f[5]=float(s.num_partitions/64.0);f[6]=float(build);f[7]=float(s.operators[o].phase==Phase::PROBE);
        f[8]=float(nr/q);f[9]=float(mx/m);f[10]=nr?float(mn/m):0;f[11]=float(sum/std::max(1,nr)/m);
        f[12]=float(sq/(sum*sum+1.0));f[13]=float(bld/m);f[14]=float(prb/m);f[15]=float(own/m);f[16]=float(bounded(own_total/(8*m)));
        bool pn=s.next_op.type=="PROBE",in=s.next_op.type=="INSERT";f[17]=float(pn);f[18]=float(in);
        if(pn||in){int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& nx=s.operators[no].partitions[np];
            f[19]=float(nx.data_size/m);f[20]=float(nx.in_memory);f[21]=float(no==o);f[22]=float((build?target.data_size+size:size)+nx.data_size<=m);}
        f[23]=float(s.write_bandwidth/10000.0);f[24]=float(s.read_bandwidth/10000.0);
        f[25]=float(double(s.miss_count)/double(std::max(uint64_t(1),now)));
        f[26]=float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_))));
        f[27]=float(h/(1+h));f[28]=float(avg/(1+avg));f[29]=float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),now-epoch_))));
        f[30]=float(selected_expert_/7.0);f[31]=float(total/(m*q));return f;
    }
    uint64_t joint_loads=0,joint_rejections=0,prefix2_plans=0;
    uint64_t interference_returns=0;
    void externalSpill(){spilled_=true;}
    uint64_t switches=0,epochs=0,allocations=0,cross_spills=0,linear_plans=0,sorted_plans=0,advanced_builds=0,certified_prefetches=0;
    explicit MySpillScheduler(int mode=-1):policy_mode_(mode),flags_(351),options_(105){}
    int selectedMode() const {return rule_;}
    std::vector<Action> onMemoryOverflow(const SystemState& s,int o,int p,int64_t bytes) override {
        choose(s,o,p,true,bytes);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+bytes;auto a=plan(s,bytes,o,p,true);spilled_=true;remember(s,a,-1);return a;
    }
    std::vector<Action> onPartitionMiss(const SystemState& s,int o,int p) override {
        choose(s,o,p,false,s.operators[o].partitions[p].data_size);requester_=o;++load_demands_;loaded(s,o,p);adapt(s,o,p);observe(o*s.num_partitions+p,o,tick(s));observeNext(s);
        int64_t size=s.operators[o].partitions[p].data_size;demand_size_=size;
        if((options_&1)&&probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            int64_t limit=(options_&2)?s.memory_limit/2:((options_&16)?s.memory_limit*3/4:s.memory_limit);
            if(s.operators[no].phase==Phase::PROBE&&!b.in_memory&&!(no==o&&np==p)&&size+b.data_size<=limit&&
                (!(options_&64)||(activeRule(false)==6&&size+b.data_size<=s.memory_limit/2&&std::max(size,b.data_size)<=2*std::min(size,b.data_size)))) {
                auto a=plan(s,size+b.data_size,o,p,false);
                bool accept=true;
                int64_t tolerance=std::max(int64_t(16),(size+b.data_size)/256),sum=0;
                if(options_&(32|64))for(const auto& v:a){
                    int64_t bytes=s.operators[v.op_id].partitions[v.partition_id].data_size;sum+=bytes;
                    if(bytes>((options_&64)?std::max(size,b.data_size)+tolerance:size+b.data_size))accept=false;
                }
                if((options_&64)&&sum>size+b.data_size+tolerance)accept=false;
                if(accept){
                    if(options_&64){
                        int64_t prefix=0,needed=size-(s.memory_limit-s.memory_used);
                        for(const auto& v:a){if(prefix>=needed)break;prefix+=s.operators[v.op_id].partitions[v.partition_id].data_size;}
                        if(s.memory_limit-s.memory_used+prefix<size+b.data_size)++compensated_misses_;
                    }
                    if(a.capacity()<a.size()+2)a.reserve(a.size()+2);
                    a.emplace_back(Action::LOAD,no,np);a.emplace_back(Action::LOAD,o,p);
                    ++load_demands_;++joint_loads;demand_size_=size+b.data_size;remember(s,a,creditRule());return a;
                }
                ++joint_rejections;
            }
        }
        auto a=plan(s,size,o,p,false);if(a.capacity()<a.size()+2)a.reserve(a.size()+2);int64_t freed=written(s,a);
        if(probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            if(s.operators[no].phase==Phase::PROBE&&!(no==o&&np==p)&&size+b.data_size<=s.memory_limit) {
                bool evicts=false;for(const auto& x:a)if(x.op_id==no&&x.partition_id==np)evicts=true;
                if(b.in_memory&&evicts) {
                    auto other=plan(s,size,o,p,false,no,np);int64_t f=written(s,other);
                    if(double(f-freed)/s.write_bandwidth<=double(b.data_size)/s.read_bandwidth+1.0){a.swap(other);freed=f;}
                }
                // Forced-victim prefetch is used at periodic callbacks only.
                // Here the existing no-extra-spill joint load remains cheaper.
                if(!b.in_memory&&s.memory_used-freed+size+b.data_size<=s.memory_limit){a.emplace_back(Action::LOAD,no,np);++load_demands_;}
            }
        }
        a.emplace_back(Action::LOAD,o,p);remember(s,a,creditRule());return a;
    }
    std::vector<Action> onPeriodicAdjust(const SystemState& s) override {
        if((flags_&1)&&s.next_op.type=="INSERT") {
            int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
            if(s.operators[o].partitions[p].in_memory&&s.next_op.tuple_size>s.memory_limit-s.memory_used) {
                choose(s,o,p,true,s.next_op.tuple_size);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+s.next_op.tuple_size;
                // PERIODIC_ADMISSION_V1: fixed next INSERT, immediate writes only.
                const int64_t admission_size=s.operators[o].partitions[p].data_size;
                const int64_t admission_tuple=s.next_op.tuple_size;
                const int64_t admission_factor=int64_t(1)<<2;
                if(admission_size>0&&admission_tuple>0&&admission_tuple<=s.memory_limit&&
                   admission_size<=s.memory_limit-admission_tuple) {
                    const int64_t admission_full=admission_size+admission_tuple;
                    if(admission_full<=s.memory_limit/admission_factor) {
                        const int64_t admission_cutoff=admission_full*admission_factor;
                        bool admission_has_other=false,admission_certified=true;
                        for(const auto& admission_op:s.operators) {
                            for(const auto& admission_part:admission_op.partitions) {
                                if(!admission_part.in_memory||admission_part.data_size<=0||
                                   (admission_op.op_id==o&&admission_part.partition_id==p))continue;
                                admission_has_other=true;
                                if(admission_part.data_size<admission_cutoff) {
                                    admission_certified=false;break;
                                }
                            }
                            if(!admission_certified)break;
                        }
                        if(admission_has_other&&admission_certified) {
                            std::vector<Action> admission_actions;admission_actions.reserve(1);
                            admission_actions.emplace_back(Action::SPILL,o,p);
                            spilled_=true;remember(s,admission_actions,-1);++advanced_builds;return admission_actions;
                        }
                    }
                }
                auto a=plan(s,s.next_op.tuple_size,o,p,true);spilled_=true;remember(s,a,-1);++advanced_builds;return a;
            }
            return {};
        }
        if(!spilled_||!probeNext(s))return {};
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);const auto& x=s.operators[o].partitions[p];
        if(s.operators[o].phase!=Phase::PROBE)return {};
        observe(o*s.num_partitions+p,o,tick(s)+1);
        if(x.in_memory)return {};
        requester_=o;demand_size_=x.data_size;std::vector<Action> a;
        if(x.data_size<=s.memory_limit-s.memory_used||forced(s,o,p,x.data_size,a,0)) {
            ++load_demands_;a.emplace_back(Action::LOAD,o,p);remember(s,a,-1);return a;
        }
        return {};
    }
};
