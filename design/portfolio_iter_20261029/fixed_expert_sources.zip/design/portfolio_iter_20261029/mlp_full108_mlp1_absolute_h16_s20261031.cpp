// Single-file C++14 scheduler. Uses only SystemState, next_op and own history.
// Flags are for reproducible local ablations; the evaluator uses no arguments.
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include <cmath>

class MySpillScheduler final : public SpillScheduler {
    // Inference sees only public state and scheduler-owned observations.
    int policy_mode_=-1,forced_next_=-1,selected_expert_=7;
    std::array<double,512> gds_{};double gds_clock_=0;
    uint64_t choices_=0,inferences_=0;
    static double bounded(double x){return std::max(0.0,std::min(1.0,x));}
    float cheapMlpTargetHeat(const SystemState& s,int o,int p) const {int id=o*s.num_partitions+p;uint64_t now=tick(s),age=now>last_[id]?now-last_[id]:0;double h=double(heat_[id])/(1.0+double(age)/64.0);return float(h/(1+h));}
static int cheapMlpDecision(const std::array<float,20>& numeric,int previous) {
    static constexpr float w1[16][20]={{8.56590271f,-1.80131781f,4.49902534f,-3.46343279f,-0.377766252f,-3.25602007f,-2.04784727f,3.99710512f,0.767446399f,-2.8386147f,1.09548271f,-0.341000259f,1.24711764f,1.98045814f,0.989036798f,-1.30832708f,-0.0947296396f,2.1843729f,0.0150234904f,3.04756904f},{-5.7237277f,-0.858462393f,-9.67858028f,5.64757299f,2.88755298f,-1.84551334f,-0.539483964f,3.63683581f,2.93746376f,-0.693027139f,-2.37372875f,0.238740534f,-0.143034548f,1.88727212f,0.116641566f,-2.88594437f,-0.0484669469f,-0.476616859f,0.0922408253f,-3.35301113f},{-1.51803517f,-0.503600299f,-1.81108773f,4.26120472f,0.429433882f,1.96890545f,1.57709599f,-0.0321951583f,-1.52884007f,-0.435275227f,0.383380651f,-2.19405937f,-0.684385419f,0.0803366378f,-1.95194864f,-0.0054166005f,0.116658293f,-1.61581957f,0.52196759f,1.24578631f},{3.61763787f,-2.2183547f,-3.50677991f,-1.06402349f,-0.860059083f,-0.305363148f,1.65482152f,-1.31454897f,-2.06363177f,-1.95844853f,-1.13510978f,-1.59075701f,-0.342202872f,0.0299880542f,2.20309663f,3.83151317f,1.44368756f,0.624292672f,0.709282398f,-1.43735814f},{1.01832914f,3.31754613f,6.77493477f,-1.28077888f,-2.36127543f,-2.71353483f,-1.09380245f,1.60617232f,4.19906807f,-1.78941202f,-1.93417871f,0.705004871f,-0.247296378f,3.4986496f,2.36577892f,-0.970954418f,-1.46501541f,-2.30064583f,0.328110009f,-1.2042861f},{5.27644968f,-4.71032858f,-3.06809998f,-7.30345011f,-0.975566149f,-0.980407238f,-2.0503242f,4.07216501f,1.80343056f,-4.36961937f,-1.87520432f,0.430621535f,1.43899214f,2.35436344f,1.33429408f,-0.707340062f,2.11084843f,-1.01284504f,-3.03828311f,1.79145253f},{-5.50056458f,3.66010427f,5.45187712f,4.50617027f,-2.16827154f,1.41760194f,-1.27434123f,1.08947754f,2.02433205f,-3.07063723f,4.787848f,-0.498317629f,1.81154525f,-2.06896424f,-2.33235121f,2.34776688f,0.67232579f,1.09702551f,1.45869005f,-1.21012616f},{0.61134845f,-1.1273061f,-1.8446306f,1.60501015f,2.75094247f,2.19841146f,0.402884424f,-1.05515623f,-0.995555639f,-1.18822634f,-0.718717277f,-2.02667308f,0.214371935f,0.149968401f,-2.14014506f,0.974407732f,4.06286049f,-0.0670074373f,-1.02276564f,0.94579643f},{-0.835886598f,-2.31747365f,-8.28419876f,1.56895161f,-2.04208779f,2.08040595f,-4.10330296f,3.37805986f,-0.0774322003f,0.747838974f,-1.08458471f,0.738981247f,0.835910857f,2.40054059f,2.29884887f,-2.57263446f,0.881568253f,-2.72390223f,-1.48576045f,-4.84935856f},{-0.304748058f,-2.48753023f,-9.05244255f,1.46616125f,1.14204371f,-2.93655419f,-1.20148289f,1.20235074f,1.9640137f,2.80057263f,1.01399767f,-0.373464048f,1.03417027f,-0.826706529f,-1.43851125f,-1.87285995f,1.2506237f,-1.27489424f,-3.30313611f,-1.20139205f},{-0.492904633f,-1.92630219f,-6.14640427f,3.01473951f,2.36490011f,0.514251649f,-0.0138571663f,0.953192532f,0.171244398f,-1.7021066f,-0.231646404f,0.325476408f,-1.64325166f,-0.218597963f,-1.87309861f,-0.301695317f,2.39780307f,1.09721744f,2.83972192f,-1.45956242f},{2.8028729f,0.389262438f,1.98511958f,-5.70620966f,1.49755478f,-2.14678288f,-2.31810141f,-0.305137396f,-3.36350155f,2.71671939f,-2.72002316f,1.78286231f,-3.02556562f,1.11757398f,-3.36192513f,0.0782680362f,-3.83011484f,0.832018197f,0.212416887f,-6.55096054f},{8.75582218f,-1.56121087f,1.44187009f,-6.45313978f,-2.68984509f,-0.356022358f,3.85464334f,0.305525512f,0.198209032f,-1.23372602f,-2.94736791f,-0.190910354f,1.14381611f,1.14211118f,-0.724036932f,1.07467997f,-1.25477147f,-0.0560995489f,0.875404298f,2.02796626f},{1.37872922f,-1.69822025f,-2.6440084f,-2.41029286f,1.59728038f,-3.59233141f,-2.41539192f,-0.796986997f,0.973941445f,-1.26854742f,-0.413299978f,0.827803493f,1.42556739f,0.713613093f,-2.04987669f,0.160683692f,2.67602062f,-0.934148133f,-1.67366683f,1.45730746f},{-2.71304536f,0.752382874f,-6.33302164f,3.04927492f,1.56415796f,1.31631541f,-0.752256036f,1.76405692f,1.35167646f,0.761909425f,-0.168575898f,-3.05813384f,-0.93485564f,-0.396616608f,-3.60291052f,0.306920201f,-0.328279287f,1.41531801f,1.7126925f,-3.00558329f},{2.01400876f,0.767149627f,1.65371013f,-0.927417636f,-1.90400147f,2.66466784f,-0.273366719f,1.53943789f,-1.80695939f,2.23824f,-0.979393065f,1.86750722f,0.425852507f,0.227705151f,-0.412815869f,1.46488512f,-1.07809472f,2.26342416f,0.69173944f,1.19584382f}};
    static constexpr float category[16][8]={{-1.01457829e-06f,-0.291189313f,0.716018915f,-0.675132036f,-0.479452103f,0.947639704f,0.157351732f,0.00124823372f},{4.74113975e-08f,-0.656399488f,-0.430078059f,0.931578398f,1.53175604f,-1.17708993f,-0.321359307f,-1.09668994f},{0.00613864046f,0.244859919f,0.607487917f,-1.19770074f,-1.68038499f,0.106799014f,0.487372279f,0.269569933f},{-2.11105466e-09f,-0.698180377f,-0.312173009f,-0.582942843f,0.427663535f,1.22198868f,0.504648566f,0.120000094f},{-2.9872802e-09f,0.895447433f,-0.0327732861f,-1.37559831f,-0.275599688f,0.822992921f,0.603361249f,0.0883453935f},{-3.99351174e-09f,-0.299893051f,1.06302917f,-0.124271698f,0.45846647f,1.63735759f,0.771811724f,0.483864576f},{-6.40725029e-09f,-0.365712911f,0.534579098f,0.732394934f,0.495779932f,-0.021297425f,-1.35915542f,-0.261228293f},{-0.0214931443f,-0.124434516f,-0.644091666f,-0.178856f,-0.095192194f,-0.0510174818f,-0.604830027f,-0.269240379f},{-4.71816586e-09f,0.767307699f,0.342566222f,-0.00532985851f,1.0709765f,0.336924434f,-0.273864925f,0.767641068f},{8.25585267e-10f,-0.477055579f,0.227481797f,0.493207753f,0.962035298f,-0.399911404f,0.480234802f,-0.39123705f},{-8.3542302e-09f,-0.120261282f,-0.84573257f,-0.236100987f,1.16518331f,-1.3487314f,-0.0985116437f,-0.0962018892f},{2.56037058e-08f,0.813501179f,1.21279597f,-0.310294628f,-1.05197716f,-0.185742825f,0.170232296f,-0.349962115f},{-0.000881029118f,0.212309256f,-0.0393725485f,-1.59987044f,-0.678859711f,0.867039502f,0.748979807f,0.160322562f},{-4.06089526e-08f,-0.840116322f,1.16273701f,0.973715067f,0.745401025f,0.986297071f,-0.0724050999f,0.119327344f},{1.43943246e-09f,0.528889f,-1.23744988f,-1.14003086f,-1.17282379f,-0.33581993f,0.48465842f,0.291382015f},{-0.00536929443f,-0.611570716f,1.22260165f,-0.617506087f,-0.155082732f,0.750255108f,-0.23953031f,0.862563074f}};
    static constexpr float b1[16]={-13.8387327f,-0.182195142f,4.22949123f,-0.433606803f,-5.56026268f,-9.28421307f,-0.223895237f,-1.42596292f,-1.24045789f,2.03633046f,-2.1373837f,5.92547512f,-7.33645296f,-0.62863642f,0.951349318f,-4.64368391f};
    static constexpr float w2[8][16]={{-1.06719327f,0.493687063f,-0.0298536774f,-0.633690536f,0.621293008f,-0.619572341f,-0.906089544f,0.0427134596f,-0.944042087f,-0.627163231f,0.0270556323f,-0.420677155f,-1.01065838f,-0.586418271f,0.0254455544f,-0.302449673f},{1.06814897f,-0.998207033f,-0.462004453f,1.14916444f,0.389629066f,0.480401993f,-0.933511496f,-0.334465086f,-0.303773284f,-0.116547436f,-1.18163574f,-0.136686683f,1.16836357f,0.470734954f,-0.934731066f,-0.0912620202f},{-1.2045604f,0.0626921877f,0.724239767f,-0.196815774f,0.105529949f,0.290852904f,0.086571157f,0.522378147f,1.03048587f,-0.0240909364f,0.335267991f,-1.57856596f,-0.548611522f,-0.570452273f,0.689270437f,-0.900984228f},{-0.174799412f,-0.359731972f,-0.286886692f,-0.504110634f,-0.440137058f,-0.392127484f,-0.094914183f,-0.204252362f,-0.278838158f,-0.193263412f,-0.109968551f,-0.153449148f,-0.408021092f,-0.469974786f,-0.177678645f,-0.0201135501f},{0.10089305f,1.02776873f,-0.697699308f,0.172702014f,-1.56575143f,0.109429799f,0.807288408f,-0.138061568f,-0.165598541f,0.888404608f,0.182623997f,-0.130800679f,-0.922434092f,0.939969838f,-0.722920895f,1.05206347f},{0.0847161412f,-0.133331403f,0.275052428f,-0.732198179f,-0.0873271301f,-1.15022242f,-0.174977273f,-0.359683961f,-0.913802266f,-0.157769427f,0.393115908f,0.558610737f,0.301096827f,-1.24732673f,1.07276511f,0.506859541f},{-0.125911295f,-0.578357637f,0.107030392f,-0.325228214f,-0.326666653f,-0.335704684f,0.930341005f,-0.428054273f,-0.269623786f,-0.140188009f,-0.238699615f,-0.601148486f,-0.705903471f,-0.392515808f,-0.789984226f,-0.223752528f},{-0.104808822f,-0.252086848f,0.184221312f,-1.12904191f,0.0799479261f,-0.949225247f,0.443087101f,-0.652845263f,-0.143017709f,-1.12885511f,-0.00219738227f,1.05967486f,-0.667981863f,-0.507813752f,-0.35493499f,-0.0660469532f}};
    static constexpr float b2[8]={0.106415525f,0.0788774118f,0.0469454564f,-0.315610081f,-0.124884412f,0.206360012f,-0.360341638f,0.288814813f};
    if(previous<0||previous>=8)previous=7;
    std::array<float,16> activation;
    for(int j=0;j<16;++j){float value=b1[j];
        for(int i=0;i<20;++i){float product=w1[j][i]*numeric[i];value=float(value+product);}
        value=float(value+category[j][previous]);activation[j]=value>0.0f?value:0.0f;}
    int best=0;float best_value=0.0f;
    for(int e=0;e<8;++e){float value=b2[e];
        for(int j=0;j<16;++j){float product=w2[e][j]*activation[j];value=float(value+product);}
        if(e==0||value>best_value){best=e;best_value=value;}}return best;
}
int route(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
    const std::array<float,20> numeric={{float(double(s.memory_used)/double(s.memory_limit)),float(double(bytes)/double(s.memory_limit)),float(std::max(0.0,double(bytes)-double(s.memory_limit-s.memory_used))/double(s.memory_limit)),float(double(s.memory_limit-s.memory_used)/double(s.memory_limit)),float(s.operators.size()/8.0),float(s.num_partitions/64.0),float(build),float(s.operators[o].phase==Phase::PROBE),float(s.next_op.type=="PROBE"),float(s.next_op.type=="INSERT"),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size/double(s.memory_limit)):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].in_memory):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.next_op.op_id==o):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float((build?s.operators[o].partitions[p].data_size+double(bytes):double(bytes))+s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size<=double(s.memory_limit)):0.0f),float(s.write_bandwidth/10000.0),float(s.read_bandwidth/10000.0),float(double(s.miss_count)/double(std::max(uint64_t(1),tick(s)))),float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),tick(s)-epoch_)))),cheapMlpTargetHeat(s,o,p),float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),tick(s)-epoch_))))}};
    return cheapMlpDecision(numeric,selected_expert_);
}
#ifdef PORTFOLIO_AUDIT
int routeReference(const std::array<float,32>& x) const {
    const std::array<float,20> numeric={{x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[17],x[18],x[19],x[20],x[21],x[22],x[23],x[24],x[25],x[26],x[27],x[29]}};
    int previous=int(double(x[30])*7.0+0.5);return cheapMlpDecision(numeric,previous);
}
#endif

    int activeRule(bool build) const {
        static const int rules[8]={0,8,3,6,4,9,4,4};
        return selected_expert_==7?(build?0:rule_):((selected_expert_==6&&build)?0:rules[selected_expert_]);
    }
    int creditRule() const {int r=activeRule(false);return (r==3||r==4||r==6)?r:-1;}
    void choose(const SystemState& s,int o,int p,bool build,int64_t bytes) {
        if(forced_next_>=0){selected_expert_=forced_next_;forced_next_=-1;}
        else if(policy_mode_>=0)selected_expert_=policy_mode_;
        else if(policy_mode_==-2)selected_expert_=int((tick(s)*6364136223846793005ULL+choices_*1442695040888963407ULL)%8);
        else {int next_expert=route(s,o,p,build,bytes);
#ifdef PORTFOLIO_AUDIT
if(next_expert!=routeReference(features(s,o,p,build,bytes)))throw std::runtime_error("route feature mismatch");
#endif
selected_expert_=next_expert;++inferences_;}
        ++choices_;
    }
    struct Victim { int o,p,id; int64_t bytes; double value,key; };
    struct Ghost { uint64_t at=0; int rule=-1; bool credited=false; int requester=-1; bool avoidable_cross=false; };
    int flags_,rule_=4,options_;
    uint64_t load_demands_=0,compensated_misses_=0;
    bool spilled_=false,first_miss_=false;
    std::array<uint64_t,512> last_{};
    std::array<float,512> heat_{};
    std::array<Ghost,512> ghost_{};
    std::array<double,8> op_heat_{},budget_{};
    std::array<uint64_t,8> op_last_{};
    std::array<double,7> loss_{};
    std::array<unsigned,7> trials_{};
    std::array<double,64> interference_{};
    std::array<uint64_t,64> interference_at_{};
    double interference(int source,int victim,uint64_t now) const {
        int i=source*8+victim;uint64_t age=now>interference_at_[i]?now-interference_at_[i]:0;
        return interference_[i]/(1.0+double(age)/256.0);
    }

    uint64_t epoch_=0,epoch_miss_=0,switched_at_=0,returns_=0,return_base_=0;
    int phase_mask_=-1;
    static uint64_t tick(const SystemState& s) {return uint64_t(s.hit_count+s.miss_count);}
    static bool probeNext(const SystemState& s) {return s.next_op.type=="PROBE";}
    static bool less(const Victim& a,const Victim& b) {
        if(a.key!=b.key)return a.key<b.key;
        if(a.bytes!=b.bytes)return a.bytes>b.bytes;
        return a.id>b.id;
    }
    static double clip(double x,double a,double b) {return std::max(a,std::min(b,x));}
    void observe(int id,int o,uint64_t now) {
        if(last_[id]==now)return;
        uint64_t age=now>last_[id]?now-last_[id]:0;
        heat_[id]=float(double(heat_[id])/(1.0+double(age)/64.0)+1.0);last_[id]=now;
        age=now>op_last_[o]?now-op_last_[o]:0;
        op_heat_[o]=op_heat_[o]/(1.0+double(age)/128.0)+1.0;op_last_[o]=now;
    }
    void observeNext(const SystemState& s) {
        if(!probeNext(s))return;
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
        if(s.operators[o].phase==Phase::PROBE){observe(o*s.num_partitions+p,o,tick(s)+1);
            double z=double(s.operators[o].partitions[p].data_size);
            gds_[o*s.num_partitions+p]=gds_clock_+(z/s.write_bandwidth+z/s.read_bandwidth+1.0)/std::max(1.0,z);}

    }
    void credit(int rule,double loss) {
        if(rule<0)return;
        loss_[rule]=trials_[rule]?0.875*loss_[rule]+0.125*loss:loss;
        ++trials_[rule];
    }
    void loaded(const SystemState& s,int o,int p) {
        int gid=o*s.num_partitions+p;double gs=double(s.operators[o].partitions[p].data_size);
        gds_[gid]=gds_clock_+(gs/s.write_bandwidth+gs/s.read_bandwidth+1.0)/std::max(1.0,gs);
        Ghost& g=ghost_[gid];
        if(!g.at)return;
        uint64_t age=tick(s)+1-g.at,width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        if(age<=width){if(g.rule>=0 || !(flags_&64))++returns_;if(!g.credited)credit(g.rule,1.0);}
        else if(!g.credited)credit(g.rule,0.0);
        if((flags_&1024)&&age<=width&&g.avoidable_cross) {
            int edge=g.requester*8+o;
            double bytes=double(s.operators[o].partitions[p].data_size);
            interference_[edge]=interference(g.requester,o,tick(s))+bytes/s.write_bandwidth+bytes/s.read_bandwidth+1.0;
            interference_at_[edge]=tick(s);++interference_returns;
        }
        g=Ghost();
    }
    void remember(const SystemState& s,const std::vector<Action>& a,int cause) {
        for(const auto& x:a) {
            if(x.type==Action::SPILL) {
                int id=x.op_id*s.num_partitions+x.partition_id;
                if(selected_expert_==5)gds_clock_=std::max(gds_clock_,gds_[id]);
                gds_[id]=0;
                ghost_[id].at=tick(s)+1;
                // If victim and demand target cannot coexist, eviction is forced;
                // do not treat its return as evidence against a discretionary rule.
                ghost_[id].rule=((flags_&64)&&cause>=0&&s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_>s.memory_limit)?-1:cause;
                ghost_[id].credited=false;ghost_[id].requester=requester_;
                ghost_[id].avoidable_cross=requester_>=0&&requester_!=x.op_id&&s.operators[x.op_id].phase==Phase::PROBE&&
                    s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_<=s.memory_limit;
                if(x.op_id!=requester_)++cross_spills;
            } else loaded(s,x.op_id,x.partition_id);
        }
    }
    int requester_=-1;int64_t demand_size_=0;
    void allocate(const SystemState& s) {
        int k=int(s.operators.size());uint64_t now=tick(s);
        std::array<double,8> cap{},w{};std::array<bool,8> done{};
        for(const auto& op:s.operators) {
            for(const auto& x:op.partitions)cap[op.op_id]+=double(x.data_size);
            int o=op.op_id;uint64_t age=now>op_last_[o]?now-op_last_[o]:0;
            double h=op_heat_[o]/(1.0+double(age)/128.0);
            w[o]=(op.phase==Phase::PROBE?1.0:0.25)*(1.0+h);budget_[o]=0;
        }
        double remaining=double(s.memory_limit);
        for(int pass=0;pass<=k;++pass) {
            double sw=0;for(int o=0;o<k;++o)if(!done[o])sw+=w[o];
            if(sw<=0)break;
            bool capped=false;
            for(int o=0;o<k;++o)if(!done[o] && cap[o]<=remaining*w[o]/sw) {
                budget_[o]=cap[o];done[o]=true;capped=true;
            }
            if(!capped){for(int o=0;o<k;++o)if(!done[o])budget_[o]=remaining*w[o]/sw;break;}
            remaining=double(s.memory_limit);for(int o=0;o<k;++o)if(done[o])remaining-=budget_[o];
        }
        ++allocations;
    }
    void adapt(const SystemState& s,int o,int p) {
        uint64_t now=tick(s);int mask=phase_mask_;
        if(mask!=((1<<int(s.operators.size()))-1)){mask=0;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)mask|=1<<op.op_id;}
        uint64_t observed_misses=(options_&8)?((options_&64)?uint64_t(s.miss_count)+compensated_misses_:load_demands_):uint64_t(s.miss_count);
        bool first=!first_miss_,urgent=returns_-return_base_>=3;
        if(!first && mask==phase_mask_ && now-epoch_<128 && observed_misses-epoch_miss_<32 && !urgent)return;
        uint64_t width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        for(int i=0,q=int(s.operators.size())*s.num_partitions;i<q;++i){auto& g=ghost_[i];if(g.at && !g.credited && now+1-g.at>width){credit(g.rule,0.0);g.credited=true;}}
        if(first) {
            first_miss_=true;
            if(flags_&32) {
                double a=double(s.operators[o].partitions[p].data_size)/s.memory_limit,b=-1;
                if(probeNext(s))b=double(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size)/s.memory_limit;
                rule_=a<=.125?(b<=.0013453512706539845?3:4):(s.operators.size()<=1?4:3);
            }
        } else if(flags_&4) {
            double rate=std::min(1.0,double(observed_misses-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_)));
            int desired=(flags_&256)?rule_:4;
            // Positive evidence for a repeat working set favours heat/byte;
            // sustained misses without quick returns favour observed recency.
            if(urgent && rate>.12)desired=6;
            else if(rate>.65 && !urgent && !(flags_&128))desired=3;
            if((flags_&256)&&desired==rule_&&rule_!=4&&rate>.30&&loss_[rule_]>.50)desired=4;
            double best=loss_[desired]+(trials_[desired]?0.0:.12);
            for(int r:{4,3,6})if(trials_[r]>=4 && loss_[r]+.12<best){desired=r;best=loss_[r];}
            uint64_t dwell=urgent?8:64;
            if(desired!=rule_ && now-switched_at_>=dwell) {
                // Hysteresis prevents a tiny sampled advantage triggering a switch.
                if(urgent || desired==4 || !trials_[rule_] || loss_[rule_]>best+.08 || rate>.65) {
                    rule_=desired;switched_at_=now;++switches;
                }
            }
        }
        epoch_=now;epoch_miss_=observed_misses;return_base_=returns_;phase_mask_=mask;++epochs;
        if(flags_&8)allocate(s);
    }
    std::vector<Action> plan(const SystemState& s,int64_t need,int to,int tp,bool build,int po=-1,int pp=-1) {
        int64_t deficit=need-(s.memory_limit-s.memory_used);if(deficit<=0)return {};
        int rule=activeRule(build);
        std::array<double,8> used{},factor{};factor.fill(1.0);
        bool quota=(selected_expert_==6||selected_expert_==7);
        if(build&&(options_&4)){bool has_probe=false;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)has_probe=true;if(!has_probe)quota=false;}
        if(quota) {
            if(build || !allocations)allocate(s);
            for(const auto& op:s.operators)for(const auto& x:op.partitions)if(x.in_memory)used[op.op_id]+=double(x.data_size);
            double pad=double(s.memory_limit)/(32.0*s.operators.size());
            for(unsigned o=0;o<s.operators.size();++o)factor[o]=clip((budget_[o]+pad)/(used[o]+pad),.5,2.0);
        }
        std::array<Victim,512> c;int n=0,best=-1;uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            int o=op.op_id,p=x.partition_id,id=o*s.num_partitions+p;
            if(!x.in_memory||x.data_size<=0||(o==to&&p==tp)||(o==po&&p==pp))continue;
            double v=0,key=-double(x.data_size)/factor[o];
            if(rule==8){v=double(x.data_size)/s.write_bandwidth;key=double(x.data_size);}
            else if(rule==9){
                if(gds_[id]==0)gds_[id]=gds_clock_+(double(x.data_size)/s.write_bandwidth+double(x.data_size)/s.read_bandwidth+1.0)/double(x.data_size);
                key=gds_[id];
            }
            else if(rule==4) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0),q=.15+.70*h/(1.0+h);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)q=1.0;
                if(op.phase==Phase::BUILD)q*=.35;
                v=(double(x.data_size)/s.write_bandwidth+q*(double(x.data_size)/s.read_bandwidth+32.0))*factor[o];
                key=v/double(x.data_size);
            } else if(rule==3)key=(double(last_[id])+1.0)*factor[o];
            else if(rule==6) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0);
                key=(1.0+h)*factor[o]/double(x.data_size);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)key*=16.0;
            }
            if((flags_&1024)&&requester_>=0&&requester_!=o) {
                double unit=double(s.memory_limit)*(1.0/s.write_bandwidth+1.0/s.read_bandwidth)+1.0;
                double charge=1.0+std::min(3.0,interference(requester_,o,now)/unit);
                if(rule==0)key/=charge;else {key*=charge;v*=charge;}
            }
            c[n]={o,p,id,x.data_size,v,key};if(best<0||less(c[n],c[best]))best=n;++n;
        }
        // Every resident x with size(x)>M-locked is infeasible beside the
        // partitions which this request must retain. Such x must be spilled.
        // If forced victims cover the deficit, this set attains the unavoidable
        // immediate-write lower bound. No future-Score optimality is claimed.
        int64_t locked=build?s.operators[to].partitions[tp].data_size+need:need;
        if(po>=0&&!(po==to&&pp==tp)&&s.operators[po].partitions[pp].in_memory)
            locked+=s.operators[po].partitions[pp].data_size;
        if(locked<=s.memory_limit){
            int64_t forced_bytes=0;
            for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)forced_bytes+=c[i].bytes;
            if(forced_bytes>=deficit){
                std::vector<Action> a;a.reserve(n+2);
                for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                return a;
            }
        }
        // Exact minimum immediate write bytes for <=10 eligible candidates.
        // Larger instances use size order + covering singleton, without an optimality claim.
        if(rule==8&&n<=10){
            int64_t best_bytes=INT64_MAX;unsigned best_mask=0;
            std::array<int64_t,1024> sums;sums[0]=0;unsigned count=1;
            for(int i=0;i<n;++i){
                for(unsigned j=0;j<count;++j){unsigned mask=count+j;sums[mask]=sums[j]+c[i].bytes;
                    if(sums[mask]>=deficit&&sums[mask]<best_bytes){best_bytes=sums[mask];best_mask=mask;}}
                count*=2;
            }
            std::vector<Action> a;a.reserve(n+2);
            for(int i=0;i<n;++i)if(best_mask&(1u<<i))a.emplace_back(Action::SPILL,c[i].o,c[i].p);
            return a;
        }
        // The sorted greedy prefix has length one in this case. Select the
        // same minimum-cost covering singleton in O(Q), preserving tie order.
        if((flags_&16) && best>=0 && c[best].bytes>=deficit) {
            int chosen=best;
            if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit &&
                (c[i].value<c[chosen].value || (c[i].value==c[chosen].value&&less(c[i],c[chosen]))))chosen=i;
            ++linear_plans;std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[chosen].o,c[chosen].p);return a;
        }
        // Exact shortcut for a sorted greedy prefix of length two.
        // No heuristic truncation: all covering singletons are still compared.
        if(best>=0&&c[best].bytes<deficit) {
            int second=-1;
            for(int i=0;i<n;++i)if(i!=best&&(second<0||less(c[i],c[second])))second=i;
            if(second>=0&&c[best].bytes+c[second].bytes>=deficit) {
                int64_t freed=c[best].bytes+c[second].bytes;
                double value=c[best].value+c[second].value;int single=-1;
                if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit) {
                    if(c[i].value<value){single=i;value=c[i].value;}
                    else if(single>=0&&c[i].value==value&&less(c[i],c[single]))single=i;
                }
                std::vector<Action> a;a.reserve(2+(build?0:2));
                if(single>=0)a.emplace_back(Action::SPILL,c[single].o,c[single].p);
                else {
                    for(int i:{best,second}) {
                        if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
                        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                    }
                }
                ++prefix2_plans;return a;
            }
        }
        ++sorted_plans;std::sort(c.begin(),c.begin()+n,less);
        int take=0;int64_t freed=0;double value=0;
        while(take<n&&freed<deficit){freed+=c[take].bytes;value+=c[take].value;++take;}
        if(rule==4||rule==8) {
            int single=-1;for(int i=0;i<n;++i)if(c[i].bytes>=deficit&&c[i].value<value){single=i;value=c[i].value;}
            if(single>=0){std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[single].o,c[single].p);return a;}
        }
        std::vector<Action> a;a.reserve(take+(build?0:2));
        for(int i=0;i<take;++i)if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
        return a;
    }
    static int64_t written(const SystemState& s,const std::vector<Action>& a) {
        int64_t n=0;for(const auto& x:a)if(x.type==Action::SPILL)n+=s.operators[x.op_id].partitions[x.partition_id].data_size;return n;
    }
    // Local certificate: any resident x with size(x)>M-size(B) MUST leave
    // before B can be loaded. Only prefetch when these forced victims suffice.
    bool forced(const SystemState& s,int o,int p,int64_t need,std::vector<Action>& a,int64_t freed) {
        if(!(flags_&2)||need<s.memory_limit/2)return false;
        int64_t deficit=need-(s.memory_limit-s.memory_used+freed);if(deficit<=0)return true;
        std::array<bool,512> removed{};
        for(const auto& x:a)if(x.type==Action::SPILL)removed[x.op_id*s.num_partitions+x.partition_id]=true;
        std::vector<Action> extra;int64_t sum=0;
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            if(x.in_memory&&x.data_size>s.memory_limit-need&&!removed[op.op_id*s.num_partitions+x.partition_id]&&!(op.op_id==o&&x.partition_id==p)) {
                extra.emplace_back(Action::SPILL,op.op_id,x.partition_id);sum+=x.data_size;
            }
        }
        if(sum<deficit)return false;
        a.insert(a.end(),extra.begin(),extra.end());++certified_prefetches;return true;
    }
public:

    void forceNext(int x){forced_next_=x;}
    void setMode(int x){policy_mode_=x;}
    int lastExpert() const{return selected_expert_;}
    uint64_t inferenceCount() const{return inferences_;}
    std::array<float,32> features(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
        std::array<float,32> f{};double m=double(s.memory_limit),sum=0,sq=0,mx=0,mn=m,bld=0,prb=0,own=0,total=0,own_total=0,heat=0;int nr=0;
        uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions){
            total+=x.data_size;if(op.op_id==o)own_total+=x.data_size;
            if(!x.in_memory||x.data_size<=0)continue;
            double z=double(x.data_size);sum+=z;sq+=z*z;mx=std::max(mx,z);mn=std::min(mn,z);++nr;
            if(op.phase==Phase::BUILD)bld+=z;else prb+=z;if(op.op_id==o)own+=z;
            int id=op.op_id*s.num_partitions+x.partition_id;uint64_t age=now>last_[id]?now-last_[id]:0;
            heat+=double(heat_[id])/(1.0+double(age)/64.0);
        }
        double free=double(s.memory_limit-s.memory_used),size=double(bytes),q=double(s.operators.size()*s.num_partitions);
        const auto& target=s.operators[o].partitions[p];int tid=o*s.num_partitions+p;uint64_t age=now>last_[tid]?now-last_[tid]:0;
        double h=double(heat_[tid])/(1.0+double(age)/64.0),avg=heat/std::max(1,nr);
        f[0]=float(s.memory_used/m);f[1]=float(size/m);f[2]=float(std::max(0.0,size-free)/m);f[3]=float(free/m);
        f[4]=float(s.operators.size()/8.0);f[5]=float(s.num_partitions/64.0);f[6]=float(build);f[7]=float(s.operators[o].phase==Phase::PROBE);
        f[8]=float(nr/q);f[9]=float(mx/m);f[10]=nr?float(mn/m):0;f[11]=float(sum/std::max(1,nr)/m);
        f[12]=float(sq/(sum*sum+1.0));f[13]=float(bld/m);f[14]=float(prb/m);f[15]=float(own/m);f[16]=float(bounded(own_total/(8*m)));
        bool pn=s.next_op.type=="PROBE",in=s.next_op.type=="INSERT";f[17]=float(pn);f[18]=float(in);
        if(pn||in){int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& nx=s.operators[no].partitions[np];
            f[19]=float(nx.data_size/m);f[20]=float(nx.in_memory);f[21]=float(no==o);f[22]=float((build?target.data_size+size:size)+nx.data_size<=m);}
        f[23]=float(s.write_bandwidth/10000.0);f[24]=float(s.read_bandwidth/10000.0);
        f[25]=float(double(s.miss_count)/double(std::max(uint64_t(1),now)));
        f[26]=float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_))));
        f[27]=float(h/(1+h));f[28]=float(avg/(1+avg));f[29]=float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),now-epoch_))));
        f[30]=float(selected_expert_/7.0);f[31]=float(total/(m*q));return f;
    }
    uint64_t joint_loads=0,joint_rejections=0,prefix2_plans=0;
    uint64_t interference_returns=0;
    void externalSpill(){spilled_=true;}
    uint64_t switches=0,epochs=0,allocations=0,cross_spills=0,linear_plans=0,sorted_plans=0,advanced_builds=0,certified_prefetches=0;
    explicit MySpillScheduler(int mode=-1):policy_mode_(mode),flags_(351),options_(105){}
    int selectedMode() const {return rule_;}
    std::vector<Action> onMemoryOverflow(const SystemState& s,int o,int p,int64_t bytes) override {
        choose(s,o,p,true,bytes);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+bytes;auto a=plan(s,bytes,o,p,true);spilled_=true;remember(s,a,-1);return a;
    }
    std::vector<Action> onPartitionMiss(const SystemState& s,int o,int p) override {
        choose(s,o,p,false,s.operators[o].partitions[p].data_size);requester_=o;++load_demands_;loaded(s,o,p);adapt(s,o,p);observe(o*s.num_partitions+p,o,tick(s));observeNext(s);
        int64_t size=s.operators[o].partitions[p].data_size;demand_size_=size;
        if((options_&1)&&probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            int64_t limit=(options_&2)?s.memory_limit/2:((options_&16)?s.memory_limit*3/4:s.memory_limit);
            if(s.operators[no].phase==Phase::PROBE&&!b.in_memory&&!(no==o&&np==p)&&size+b.data_size<=limit&&
                (!(options_&64)||(activeRule(false)==6&&size+b.data_size<=s.memory_limit/2&&std::max(size,b.data_size)<=2*std::min(size,b.data_size)))) {
                auto a=plan(s,size+b.data_size,o,p,false);
                bool accept=true;
                int64_t tolerance=std::max(int64_t(16),(size+b.data_size)/256),sum=0;
                if(options_&(32|64))for(const auto& v:a){
                    int64_t bytes=s.operators[v.op_id].partitions[v.partition_id].data_size;sum+=bytes;
                    if(bytes>((options_&64)?std::max(size,b.data_size)+tolerance:size+b.data_size))accept=false;
                }
                if((options_&64)&&sum>size+b.data_size+tolerance)accept=false;
                if(accept){
                    if(options_&64){
                        int64_t prefix=0,needed=size-(s.memory_limit-s.memory_used);
                        for(const auto& v:a){if(prefix>=needed)break;prefix+=s.operators[v.op_id].partitions[v.partition_id].data_size;}
                        if(s.memory_limit-s.memory_used+prefix<size+b.data_size)++compensated_misses_;
                    }
                    if(a.capacity()<a.size()+2)a.reserve(a.size()+2);
                    a.emplace_back(Action::LOAD,no,np);a.emplace_back(Action::LOAD,o,p);
                    ++load_demands_;++joint_loads;demand_size_=size+b.data_size;remember(s,a,creditRule());return a;
                }
                ++joint_rejections;
            }
        }
        auto a=plan(s,size,o,p,false);if(a.capacity()<a.size()+2)a.reserve(a.size()+2);int64_t freed=written(s,a);
        if(probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            if(s.operators[no].phase==Phase::PROBE&&!(no==o&&np==p)&&size+b.data_size<=s.memory_limit) {
                bool evicts=false;for(const auto& x:a)if(x.op_id==no&&x.partition_id==np)evicts=true;
                if(b.in_memory&&evicts) {
                    auto other=plan(s,size,o,p,false,no,np);int64_t f=written(s,other);
                    if(double(f-freed)/s.write_bandwidth<=double(b.data_size)/s.read_bandwidth+1.0){a.swap(other);freed=f;}
                }
                // Forced-victim prefetch is used at periodic callbacks only.
                // Here the existing no-extra-spill joint load remains cheaper.
                if(!b.in_memory&&s.memory_used-freed+size+b.data_size<=s.memory_limit){a.emplace_back(Action::LOAD,no,np);++load_demands_;}
            }
        }
        a.emplace_back(Action::LOAD,o,p);remember(s,a,creditRule());return a;
    }
    std::vector<Action> onPeriodicAdjust(const SystemState& s) override {
        if((flags_&1)&&s.next_op.type=="INSERT") {
            int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
            if(s.operators[o].partitions[p].in_memory&&s.next_op.tuple_size>s.memory_limit-s.memory_used) {
                choose(s,o,p,true,s.next_op.tuple_size);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+s.next_op.tuple_size;
                // PERIODIC_ADMISSION_V1: fixed next INSERT, immediate writes only.
                const int64_t admission_size=s.operators[o].partitions[p].data_size;
                const int64_t admission_tuple=s.next_op.tuple_size;
                const int64_t admission_factor=int64_t(1)<<2;
                if(admission_size>0&&admission_tuple>0&&admission_tuple<=s.memory_limit&&
                   admission_size<=s.memory_limit-admission_tuple) {
                    const int64_t admission_full=admission_size+admission_tuple;
                    if(admission_full<=s.memory_limit/admission_factor) {
                        const int64_t admission_cutoff=admission_full*admission_factor;
                        bool admission_has_other=false,admission_certified=true;
                        for(const auto& admission_op:s.operators) {
                            for(const auto& admission_part:admission_op.partitions) {
                                if(!admission_part.in_memory||admission_part.data_size<=0||
                                   (admission_op.op_id==o&&admission_part.partition_id==p))continue;
                                admission_has_other=true;
                                if(admission_part.data_size<admission_cutoff) {
                                    admission_certified=false;break;
                                }
                            }
                            if(!admission_certified)break;
                        }
                        if(admission_has_other&&admission_certified) {
                            std::vector<Action> admission_actions;admission_actions.reserve(1);
                            admission_actions.emplace_back(Action::SPILL,o,p);
                            spilled_=true;remember(s,admission_actions,-1);++advanced_builds;return admission_actions;
                        }
                    }
                }
                auto a=plan(s,s.next_op.tuple_size,o,p,true);spilled_=true;remember(s,a,-1);++advanced_builds;return a;
            }
            return {};
        }
        if(!spilled_||!probeNext(s))return {};
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);const auto& x=s.operators[o].partitions[p];
        if(s.operators[o].phase!=Phase::PROBE)return {};
        observe(o*s.num_partitions+p,o,tick(s)+1);
        if(x.in_memory)return {};
        requester_=o;demand_size_=x.data_size;std::vector<Action> a;
        if(x.data_size<=s.memory_limit-s.memory_used||forced(s,o,p,x.data_size,a,0)) {
            ++load_demands_;a.emplace_back(Action::LOAD,o,p);remember(s,a,-1);return a;
        }
        return {};
    }
};
