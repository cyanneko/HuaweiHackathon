// Single-file C++14 scheduler. Uses only SystemState, next_op and own history.
// Flags are for reproducible local ablations; the evaluator uses no arguments.
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include <cmath>

class MySpillScheduler final : public SpillScheduler {
    // Inference sees only public state and scheduler-owned observations.
    int policy_mode_=-1,forced_next_=-1,selected_expert_=7;
    std::array<double,512> gds_{};double gds_clock_=0;
    uint64_t choices_=0,inferences_=0;
    static double bounded(double x){return std::max(0.0,std::min(1.0,x));}
    float cheapMlpTargetHeat(const SystemState& s,int o,int p) const {int id=o*s.num_partitions+p;uint64_t now=tick(s),age=now>last_[id]?now-last_[id]:0;double h=double(heat_[id])/(1.0+double(age)/64.0);return float(h/(1+h));}
static int cheapMlpDecision(const std::array<float,20>& numeric,int previous) {
    static constexpr float w1[16][20]={{4.93540668f,-1.89062345f,2.07852244f,0.15000622f,0.0845239088f,-0.733832836f,-0.776496768f,2.71131635f,-0.349593461f,-1.70778f,2.21305442f,-0.168216288f,0.661791384f,0.787944376f,0.775093853f,0.537941933f,-0.470382154f,1.06035042f,-0.667508185f,-0.370986581f},{-1.66539383f,0.538000166f,-1.77372873f,1.58961225f,1.67330599f,-2.47083759f,1.31773019f,1.74648237f,0.990443826f,1.22956359f,0.371004432f,0.258122683f,0.170635238f,1.1704241f,0.343342006f,-0.62500304f,-0.536269844f,-0.081949085f,0.711973965f,-1.82826853f},{-0.323740423f,0.172725245f,1.09007692f,3.05901074f,-0.949295044f,0.370639175f,2.28358364f,-0.749116361f,-0.963375866f,-0.981807411f,-0.407709956f,-0.501918077f,-0.589416802f,-0.189186901f,-0.776099205f,0.778386354f,-0.630478919f,-0.818122447f,0.0318744257f,1.93678486f},{1.94849622f,-0.46871984f,-0.693120122f,0.596025646f,-0.439619064f,0.152180836f,0.237134412f,0.101011887f,-2.74605727f,-1.26275992f,-0.546542346f,-0.831471026f,-0.279976666f,0.338231415f,0.901581466f,2.29068947f,1.34792757f,-0.319423854f,0.356794208f,-0.0125376023f},{-0.280433297f,1.23994946f,1.91405118f,0.0186567139f,-1.15267634f,-1.37128496f,0.276366323f,0.232616216f,2.59569097f,-0.20360072f,-1.07018685f,-0.446146786f,-0.25299561f,2.51619673f,0.867307663f,-0.539236426f,-0.133829817f,-1.0522697f,-0.248769239f,-1.65552878f},{1.67464805f,-2.14297509f,-0.492116928f,-3.68753529f,-0.0759049356f,-0.0875262767f,-0.550834596f,2.54208779f,0.464868337f,-2.99777341f,-0.9580217f,0.342322946f,-0.5288378f,1.35343659f,1.48476946f,-0.202176169f,1.39463449f,0.349843949f,0.170657933f,2.48088312f},{-1.96650624f,0.0265992638f,1.85385382f,0.978271306f,-0.546752989f,0.772526443f,0.958042383f,-1.1406517f,0.285470843f,-1.30812311f,3.62660098f,0.269264072f,0.165488496f,-0.658843935f,-0.412152946f,-0.221546635f,-0.389537722f,-0.23948808f,1.03185368f,0.289399296f},{2.66996741f,-1.25890076f,-1.00964046f,-0.46170038f,1.9952966f,1.27507448f,0.505706787f,-1.15459025f,-1.2099787f,-0.962669551f,-1.18236232f,-1.5387466f,-0.479095608f,0.947212875f,-1.59108889f,-0.238932699f,3.11024499f,0.836223185f,-0.735916913f,1.71739733f},{-0.455170602f,-0.561313212f,-2.78386879f,1.18574536f,-0.796695411f,-0.176743343f,-2.59436345f,1.87934721f,-0.727550805f,1.39540136f,-0.666625857f,-0.223962843f,0.147201136f,1.36839306f,1.06865191f,-1.00488114f,0.517753243f,-0.296651393f,0.39542976f,-2.04269981f},{1.07014394f,0.0310528986f,-1.88703418f,0.0863341019f,-0.271825671f,-1.55884206f,-0.741064668f,0.741926253f,0.970522046f,3.77185416f,1.17090917f,-0.21965912f,-0.0468239076f,0.816979766f,-0.728188634f,-1.32742655f,0.617389381f,-0.965883732f,-1.35067189f,0.153831616f},{1.902408f,-1.24530554f,-2.75350952f,0.612009764f,1.62850499f,-0.00905636139f,-1.02796519f,1.95989013f,0.272220582f,-1.79244459f,-1.02290499f,-0.543800592f,-0.78371948f,0.32351467f,-0.99877739f,-1.13107371f,3.03001547f,1.26241636f,1.84044981f,0.720439374f},{-0.217219472f,0.122949049f,-1.10960519f,-2.67613983f,0.423684835f,-0.122440308f,-2.98748565f,0.375891834f,-1.48619545f,0.844969332f,-2.34537649f,1.33977747f,-1.07683635f,-0.211698398f,-0.830325961f,-0.468268991f,-1.36358058f,0.827884197f,-1.10664427f,-4.10358477f},{2.93119717f,0.564075768f,2.05993843f,-0.63936311f,-1.44485319f,0.747319877f,2.74321771f,1.4020468f,0.127287105f,-1.16593051f,-1.40226412f,-0.15590027f,0.409413576f,0.0741742104f,-0.408811361f,1.35984051f,-0.0978091061f,0.0167205203f,0.17764087f,-1.51068342f},{-0.790404618f,0.248738185f,-0.428493023f,-0.237720385f,0.434147298f,-1.13365495f,-1.22561574f,-1.94139695f,-0.260659635f,-0.0302563831f,0.355090171f,-0.138926759f,0.402968884f,0.846685827f,-0.342139602f,0.784245908f,1.68785107f,-1.17968869f,1.19098294f,1.90446901f},{0.339607239f,0.0988594219f,-4.86123466f,-0.00398981199f,1.77209699f,0.731383622f,-0.716369033f,1.72400367f,1.07022643f,1.03699791f,-1.35092807f,-1.55320883f,-0.608110726f,-0.276133388f,-2.28119326f,-0.362123311f,0.309868872f,1.57545018f,1.01548696f,-0.737642884f},{-0.490112394f,1.20647776f,0.353598863f,1.57208884f,-0.408300459f,1.79838204f,-0.445528567f,1.70201325f,-0.880464017f,1.3081876f,-1.85934246f,0.626328766f,0.928905725f,-0.844341338f,0.494601101f,0.749123633f,-0.642261803f,0.916504562f,0.28562659f,0.296586841f}};
    static constexpr float category[16][8]={{3.11840287e-29f,-0.090160735f,0.34083727f,-0.713601053f,-0.202012986f,0.418534338f,-0.501893282f,-3.34099883e-18f},{2.35270215e-27f,-0.500594795f,-0.11521709f,-0.129278973f,0.607542276f,-0.173176244f,0.1692902f,0.0736753941f},{4.04621074e-16f,-0.238084137f,0.0717514455f,-0.197584718f,-0.494568527f,0.459915549f,-0.0936646387f,0.0737041607f},{-8.07585157e-30f,-0.105660871f,-0.0126115438f,-0.466299713f,-0.0705340281f,0.50657481f,-0.0959272683f,0.125380889f},{7.16838037e-31f,0.45517534f,-0.419518977f,-0.34397763f,0.213146031f,0.272420883f,0.268639833f,-0.1567408f},{1.99244389e-29f,0.048457846f,-0.0652078316f,0.194812208f,0.509395838f,0.754091263f,0.382385105f,-1.9696451e-15f},{-8.10179069e-30f,-0.236668512f,-0.486773938f,-0.264014155f,0.473648787f,-0.440488011f,-0.607739806f,-0.0550822392f},{-9.79846759e-11f,-0.290703237f,-0.732162356f,-0.192069814f,-0.0226270165f,0.319182128f,-0.296610653f,-0.0118873138f},{-9.77849853e-30f,0.494169176f,-0.0528327711f,-0.0260433313f,1.01546466f,0.622976184f,-0.225319415f,0.199666813f},{1.75251349e-30f,0.447413266f,0.0692554638f,-0.394897223f,0.835519254f,0.0609980784f,0.310818821f,-0.131745651f},{2.83559631e-29f,0.318516999f,-0.467655569f,-0.358940572f,0.538128614f,-0.303969979f,0.00802600477f,-1.97017277e-29f},{-9.3953778e-29f,0.200806305f,0.689470589f,0.139145747f,-0.270934373f,-0.0778728649f,0.0132184178f,-0.640999675f},{1.71275687e-22f,0.227217957f,0.331470251f,-0.86535579f,-0.237411544f,0.45794636f,-0.218693808f,0.0573304705f},{-1.35666586e-28f,-0.291526496f,0.486909926f,-0.157404304f,0.255588472f,-0.267476857f,-0.155462742f,-0.545422852f},{-2.26238509e-27f,0.203176692f,-0.580474734f,-0.0980766714f,0.207712486f,-0.152697533f,0.184986234f,0.336628944f},{-3.05834547e-17f,-0.0401573032f,0.402261078f,-0.679891467f,0.164536282f,0.333012581f,-0.525524497f,0.395182133f}};
    static constexpr float b1[16]={-8.00134945f,-1.7631582f,3.17258072f,-0.307932049f,-2.09127712f,-5.50471497f,1.85210264f,-2.13950324f,-0.879514515f,-0.886637628f,-5.51245594f,4.15737772f,-4.18399f,1.10385001f,-2.30364871f,-1.94180822f};
    static constexpr float w2[8][16]={{-0.260202914f,-0.113337696f,-0.0374104083f,-0.0730115771f,0.150054693f,0.112832032f,-0.264781237f,0.179529056f,-0.0646337122f,-0.297289729f,0.188369289f,-0.147329852f,-0.175763354f,-0.0387227423f,0.178065553f,-0.162393749f},{0.0672372729f,-0.202321947f,0.0056637777f,0.129018068f,0.0146653978f,-0.155918673f,-0.101314165f,-0.107519656f,-0.124717459f,-0.0756205916f,-0.356187463f,-0.297952235f,0.249864802f,-0.0326904766f,-0.352972388f,0.0121423174f},{-0.239700884f,0.112239107f,-0.062013343f,0.059307266f,0.230781198f,0.136891007f,-0.0178182051f,0.12975812f,0.217553779f,0.173497096f,0.17629841f,-0.095684275f,-0.10935846f,-0.0154360551f,0.244934171f,-0.111105204f},{0.108009949f,-0.115006566f,-0.201973736f,-0.351332992f,-0.00442220643f,0.00389919709f,-0.111167826f,-0.157312527f,0.153694108f,0.171400487f,-0.0877359435f,0.0983991101f,-0.0595661029f,-0.117782578f,-0.138715521f,0.0667081997f},{-0.0783212557f,0.0199515857f,0.0949714705f,0.0884561911f,-0.500100195f,-0.114398569f,0.0610094033f,-0.248110265f,-0.0631935f,-0.0983749777f,-0.153291494f,-0.240318835f,0.0821768418f,0.118781388f,-0.424771011f,0.0534258708f},{0.0697093382f,-0.0774339885f,0.0520736501f,-0.145668238f,-0.266536921f,-0.122804746f,-0.037120264f,-0.159495607f,-0.123385444f,-0.0205134749f,-0.165491775f,0.0359117985f,-0.0440692864f,-0.239004344f,0.171037018f,0.135072425f},{0.0696269646f,-0.047355473f,0.0116515206f,0.139706805f,-0.0177830476f,-0.110791117f,0.0519523881f,-0.32333529f,-0.0441078022f,-0.105594859f,-0.125787109f,-0.417208225f,-0.161806107f,-0.0459793732f,-0.486640781f,-0.228556037f},{0.0827532783f,0.0261742547f,-0.123878606f,-0.230089128f,-0.13344577f,-0.168492183f,0.141366869f,-0.232428566f,-0.213881448f,0.0495562218f,-0.113550268f,0.363339424f,-0.25266993f,-0.00703175925f,-0.101870455f,-0.0397293158f}};
    static constexpr float b2[8]={0.0834724456f,-0.0936421752f,0.124399617f,-0.0508139357f,-0.107366897f,0.0287455823f,-0.346375942f,0.0932877436f};
    if(previous<0||previous>=8)previous=7;
    std::array<float,16> activation;
    for(int j=0;j<16;++j){float value=b1[j];
        for(int i=0;i<20;++i){float product=w1[j][i]*numeric[i];value=float(value+product);}
        value=float(value+category[j][previous]);activation[j]=value>0.0f?value:0.0f;}
    int best=0;float best_value=0.0f;
    for(int e=0;e<8;++e){float value=b2[e];
        for(int j=0;j<16;++j){float product=w2[e][j]*activation[j];value=float(value+product);}
        if(e==0||value>best_value){best=e;best_value=value;}}return best;
}
int route(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
    const std::array<float,20> numeric={{float(double(s.memory_used)/double(s.memory_limit)),float(double(bytes)/double(s.memory_limit)),float(std::max(0.0,double(bytes)-double(s.memory_limit-s.memory_used))/double(s.memory_limit)),float(double(s.memory_limit-s.memory_used)/double(s.memory_limit)),float(s.operators.size()/8.0),float(s.num_partitions/64.0),float(build),float(s.operators[o].phase==Phase::PROBE),float(s.next_op.type=="PROBE"),float(s.next_op.type=="INSERT"),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size/double(s.memory_limit)):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].in_memory):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.next_op.op_id==o):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float((build?s.operators[o].partitions[p].data_size+double(bytes):double(bytes))+s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size<=double(s.memory_limit)):0.0f),float(s.write_bandwidth/10000.0),float(s.read_bandwidth/10000.0),float(double(s.miss_count)/double(std::max(uint64_t(1),tick(s)))),float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),tick(s)-epoch_)))),cheapMlpTargetHeat(s,o,p),float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),tick(s)-epoch_))))}};
    return cheapMlpDecision(numeric,selected_expert_);
}
#ifdef PORTFOLIO_AUDIT
int routeReference(const std::array<float,32>& x) const {
    const std::array<float,20> numeric={{x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[17],x[18],x[19],x[20],x[21],x[22],x[23],x[24],x[25],x[26],x[27],x[29]}};
    int previous=int(double(x[30])*7.0+0.5);return cheapMlpDecision(numeric,previous);
}
#endif

    int activeRule(bool build) const {
        static const int rules[8]={0,8,3,6,4,9,4,4};
        return selected_expert_==7?(build?0:rule_):((selected_expert_==6&&build)?0:rules[selected_expert_]);
    }
    int creditRule() const {int r=activeRule(false);return (r==3||r==4||r==6)?r:-1;}
    void choose(const SystemState& s,int o,int p,bool build,int64_t bytes) {
        if(forced_next_>=0){selected_expert_=forced_next_;forced_next_=-1;}
        else if(policy_mode_>=0)selected_expert_=policy_mode_;
        else if(policy_mode_==-2)selected_expert_=int((tick(s)*6364136223846793005ULL+choices_*1442695040888963407ULL)%8);
        else {int next_expert=route(s,o,p,build,bytes);
#ifdef PORTFOLIO_AUDIT
if(next_expert!=routeReference(features(s,o,p,build,bytes)))throw std::runtime_error("route feature mismatch");
#endif
selected_expert_=next_expert;++inferences_;}
        ++choices_;
    }
    struct Victim { int o,p,id; int64_t bytes; double value,key; };
    struct Ghost { uint64_t at=0; int rule=-1; bool credited=false; int requester=-1; bool avoidable_cross=false; };
    int flags_,rule_=4,options_;
    uint64_t load_demands_=0,compensated_misses_=0;
    bool spilled_=false,first_miss_=false;
    std::array<uint64_t,512> last_{};
    std::array<float,512> heat_{};
    std::array<Ghost,512> ghost_{};
    std::array<double,8> op_heat_{},budget_{};
    std::array<uint64_t,8> op_last_{};
    std::array<double,7> loss_{};
    std::array<unsigned,7> trials_{};
    std::array<double,64> interference_{};
    std::array<uint64_t,64> interference_at_{};
    double interference(int source,int victim,uint64_t now) const {
        int i=source*8+victim;uint64_t age=now>interference_at_[i]?now-interference_at_[i]:0;
        return interference_[i]/(1.0+double(age)/256.0);
    }

    uint64_t epoch_=0,epoch_miss_=0,switched_at_=0,returns_=0,return_base_=0;
    int phase_mask_=-1;
    static uint64_t tick(const SystemState& s) {return uint64_t(s.hit_count+s.miss_count);}
    static bool probeNext(const SystemState& s) {return s.next_op.type=="PROBE";}
    static bool less(const Victim& a,const Victim& b) {
        if(a.key!=b.key)return a.key<b.key;
        if(a.bytes!=b.bytes)return a.bytes>b.bytes;
        return a.id>b.id;
    }
    static double clip(double x,double a,double b) {return std::max(a,std::min(b,x));}
    void observe(int id,int o,uint64_t now) {
        if(last_[id]==now)return;
        uint64_t age=now>last_[id]?now-last_[id]:0;
        heat_[id]=float(double(heat_[id])/(1.0+double(age)/64.0)+1.0);last_[id]=now;
        age=now>op_last_[o]?now-op_last_[o]:0;
        op_heat_[o]=op_heat_[o]/(1.0+double(age)/128.0)+1.0;op_last_[o]=now;
    }
    void observeNext(const SystemState& s) {
        if(!probeNext(s))return;
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
        if(s.operators[o].phase==Phase::PROBE){observe(o*s.num_partitions+p,o,tick(s)+1);
            double z=double(s.operators[o].partitions[p].data_size);
            gds_[o*s.num_partitions+p]=gds_clock_+(z/s.write_bandwidth+z/s.read_bandwidth+1.0)/std::max(1.0,z);}

    }
    void credit(int rule,double loss) {
        if(rule<0)return;
        loss_[rule]=trials_[rule]?0.875*loss_[rule]+0.125*loss:loss;
        ++trials_[rule];
    }
    void loaded(const SystemState& s,int o,int p) {
        int gid=o*s.num_partitions+p;double gs=double(s.operators[o].partitions[p].data_size);
        gds_[gid]=gds_clock_+(gs/s.write_bandwidth+gs/s.read_bandwidth+1.0)/std::max(1.0,gs);
        Ghost& g=ghost_[gid];
        if(!g.at)return;
        uint64_t age=tick(s)+1-g.at,width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        if(age<=width){if(g.rule>=0 || !(flags_&64))++returns_;if(!g.credited)credit(g.rule,1.0);}
        else if(!g.credited)credit(g.rule,0.0);
        if((flags_&1024)&&age<=width&&g.avoidable_cross) {
            int edge=g.requester*8+o;
            double bytes=double(s.operators[o].partitions[p].data_size);
            interference_[edge]=interference(g.requester,o,tick(s))+bytes/s.write_bandwidth+bytes/s.read_bandwidth+1.0;
            interference_at_[edge]=tick(s);++interference_returns;
        }
        g=Ghost();
    }
    void remember(const SystemState& s,const std::vector<Action>& a,int cause) {
        for(const auto& x:a) {
            if(x.type==Action::SPILL) {
                int id=x.op_id*s.num_partitions+x.partition_id;
                if(selected_expert_==5)gds_clock_=std::max(gds_clock_,gds_[id]);
                gds_[id]=0;
                ghost_[id].at=tick(s)+1;
                // If victim and demand target cannot coexist, eviction is forced;
                // do not treat its return as evidence against a discretionary rule.
                ghost_[id].rule=((flags_&64)&&cause>=0&&s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_>s.memory_limit)?-1:cause;
                ghost_[id].credited=false;ghost_[id].requester=requester_;
                ghost_[id].avoidable_cross=requester_>=0&&requester_!=x.op_id&&s.operators[x.op_id].phase==Phase::PROBE&&
                    s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_<=s.memory_limit;
                if(x.op_id!=requester_)++cross_spills;
            } else loaded(s,x.op_id,x.partition_id);
        }
    }
    int requester_=-1;int64_t demand_size_=0;
    void allocate(const SystemState& s) {
        int k=int(s.operators.size());uint64_t now=tick(s);
        std::array<double,8> cap{},w{};std::array<bool,8> done{};
        for(const auto& op:s.operators) {
            for(const auto& x:op.partitions)cap[op.op_id]+=double(x.data_size);
            int o=op.op_id;uint64_t age=now>op_last_[o]?now-op_last_[o]:0;
            double h=op_heat_[o]/(1.0+double(age)/128.0);
            w[o]=(op.phase==Phase::PROBE?1.0:0.25)*(1.0+h);budget_[o]=0;
        }
        double remaining=double(s.memory_limit);
        for(int pass=0;pass<=k;++pass) {
            double sw=0;for(int o=0;o<k;++o)if(!done[o])sw+=w[o];
            if(sw<=0)break;
            bool capped=false;
            for(int o=0;o<k;++o)if(!done[o] && cap[o]<=remaining*w[o]/sw) {
                budget_[o]=cap[o];done[o]=true;capped=true;
            }
            if(!capped){for(int o=0;o<k;++o)if(!done[o])budget_[o]=remaining*w[o]/sw;break;}
            remaining=double(s.memory_limit);for(int o=0;o<k;++o)if(done[o])remaining-=budget_[o];
        }
        ++allocations;
    }
    void adapt(const SystemState& s,int o,int p) {
        uint64_t now=tick(s);int mask=phase_mask_;
        if(mask!=((1<<int(s.operators.size()))-1)){mask=0;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)mask|=1<<op.op_id;}
        uint64_t observed_misses=(options_&8)?((options_&64)?uint64_t(s.miss_count)+compensated_misses_:load_demands_):uint64_t(s.miss_count);
        bool first=!first_miss_,urgent=returns_-return_base_>=3;
        if(!first && mask==phase_mask_ && now-epoch_<128 && observed_misses-epoch_miss_<32 && !urgent)return;
        uint64_t width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        for(int i=0,q=int(s.operators.size())*s.num_partitions;i<q;++i){auto& g=ghost_[i];if(g.at && !g.credited && now+1-g.at>width){credit(g.rule,0.0);g.credited=true;}}
        if(first) {
            first_miss_=true;
            if(flags_&32) {
                double a=double(s.operators[o].partitions[p].data_size)/s.memory_limit,b=-1;
                if(probeNext(s))b=double(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size)/s.memory_limit;
                rule_=a<=.125?(b<=.0013453512706539845?3:4):(s.operators.size()<=1?4:3);
            }
        } else if(flags_&4) {
            double rate=std::min(1.0,double(observed_misses-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_)));
            int desired=(flags_&256)?rule_:4;
            // Positive evidence for a repeat working set favours heat/byte;
            // sustained misses without quick returns favour observed recency.
            if(urgent && rate>.12)desired=6;
            else if(rate>.65 && !urgent && !(flags_&128))desired=3;
            if((flags_&256)&&desired==rule_&&rule_!=4&&rate>.30&&loss_[rule_]>.50)desired=4;
            double best=loss_[desired]+(trials_[desired]?0.0:.12);
            for(int r:{4,3,6})if(trials_[r]>=4 && loss_[r]+.12<best){desired=r;best=loss_[r];}
            uint64_t dwell=urgent?8:64;
            if(desired!=rule_ && now-switched_at_>=dwell) {
                // Hysteresis prevents a tiny sampled advantage triggering a switch.
                if(urgent || desired==4 || !trials_[rule_] || loss_[rule_]>best+.08 || rate>.65) {
                    rule_=desired;switched_at_=now;++switches;
                }
            }
        }
        epoch_=now;epoch_miss_=observed_misses;return_base_=returns_;phase_mask_=mask;++epochs;
        if(flags_&8)allocate(s);
    }
    std::vector<Action> plan(const SystemState& s,int64_t need,int to,int tp,bool build,int po=-1,int pp=-1) {
        int64_t deficit=need-(s.memory_limit-s.memory_used);if(deficit<=0)return {};
        int rule=activeRule(build);
        std::array<double,8> used{},factor{};factor.fill(1.0);
        bool quota=(selected_expert_==6||selected_expert_==7);
        if(build&&(options_&4)){bool has_probe=false;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)has_probe=true;if(!has_probe)quota=false;}
        if(quota) {
            if(build || !allocations)allocate(s);
            for(const auto& op:s.operators)for(const auto& x:op.partitions)if(x.in_memory)used[op.op_id]+=double(x.data_size);
            double pad=double(s.memory_limit)/(32.0*s.operators.size());
            for(unsigned o=0;o<s.operators.size();++o)factor[o]=clip((budget_[o]+pad)/(used[o]+pad),.5,2.0);
        }
        std::array<Victim,512> c;int n=0,best=-1;uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            int o=op.op_id,p=x.partition_id,id=o*s.num_partitions+p;
            if(!x.in_memory||x.data_size<=0||(o==to&&p==tp)||(o==po&&p==pp))continue;
            double v=0,key=-double(x.data_size)/factor[o];
            if(rule==8){v=double(x.data_size)/s.write_bandwidth;key=double(x.data_size);}
            else if(rule==9){
                if(gds_[id]==0)gds_[id]=gds_clock_+(double(x.data_size)/s.write_bandwidth+double(x.data_size)/s.read_bandwidth+1.0)/double(x.data_size);
                key=gds_[id];
            }
            else if(rule==4) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0),q=.15+.70*h/(1.0+h);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)q=1.0;
                if(op.phase==Phase::BUILD)q*=.35;
                v=(double(x.data_size)/s.write_bandwidth+q*(double(x.data_size)/s.read_bandwidth+32.0))*factor[o];
                key=v/double(x.data_size);
            } else if(rule==3)key=(double(last_[id])+1.0)*factor[o];
            else if(rule==6) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0);
                key=(1.0+h)*factor[o]/double(x.data_size);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)key*=16.0;
            }
            if((flags_&1024)&&requester_>=0&&requester_!=o) {
                double unit=double(s.memory_limit)*(1.0/s.write_bandwidth+1.0/s.read_bandwidth)+1.0;
                double charge=1.0+std::min(3.0,interference(requester_,o,now)/unit);
                if(rule==0)key/=charge;else {key*=charge;v*=charge;}
            }
            c[n]={o,p,id,x.data_size,v,key};if(best<0||less(c[n],c[best]))best=n;++n;
        }
        // Every resident x with size(x)>M-locked is infeasible beside the
        // partitions which this request must retain. Such x must be spilled.
        // If forced victims cover the deficit, this set attains the unavoidable
        // immediate-write lower bound. No future-Score optimality is claimed.
        int64_t locked=build?s.operators[to].partitions[tp].data_size+need:need;
        if(po>=0&&!(po==to&&pp==tp)&&s.operators[po].partitions[pp].in_memory)
            locked+=s.operators[po].partitions[pp].data_size;
        if(locked<=s.memory_limit){
            int64_t forced_bytes=0;
            for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)forced_bytes+=c[i].bytes;
            if(forced_bytes>=deficit){
                std::vector<Action> a;a.reserve(n+2);
                for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                return a;
            }
        }
        // Exact minimum immediate write bytes for <=10 eligible candidates.
        // Larger instances use size order + covering singleton, without an optimality claim.
        if(rule==8&&n<=10){
            int64_t best_bytes=INT64_MAX;unsigned best_mask=0;
            std::array<int64_t,1024> sums;sums[0]=0;unsigned count=1;
            for(int i=0;i<n;++i){
                for(unsigned j=0;j<count;++j){unsigned mask=count+j;sums[mask]=sums[j]+c[i].bytes;
                    if(sums[mask]>=deficit&&sums[mask]<best_bytes){best_bytes=sums[mask];best_mask=mask;}}
                count*=2;
            }
            std::vector<Action> a;a.reserve(n+2);
            for(int i=0;i<n;++i)if(best_mask&(1u<<i))a.emplace_back(Action::SPILL,c[i].o,c[i].p);
            return a;
        }
        // The sorted greedy prefix has length one in this case. Select the
        // same minimum-cost covering singleton in O(Q), preserving tie order.
        if((flags_&16) && best>=0 && c[best].bytes>=deficit) {
            int chosen=best;
            if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit &&
                (c[i].value<c[chosen].value || (c[i].value==c[chosen].value&&less(c[i],c[chosen]))))chosen=i;
            ++linear_plans;std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[chosen].o,c[chosen].p);return a;
        }
        // Exact shortcut for a sorted greedy prefix of length two.
        // No heuristic truncation: all covering singletons are still compared.
        if(best>=0&&c[best].bytes<deficit) {
            int second=-1;
            for(int i=0;i<n;++i)if(i!=best&&(second<0||less(c[i],c[second])))second=i;
            if(second>=0&&c[best].bytes+c[second].bytes>=deficit) {
                int64_t freed=c[best].bytes+c[second].bytes;
                double value=c[best].value+c[second].value;int single=-1;
                if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit) {
                    if(c[i].value<value){single=i;value=c[i].value;}
                    else if(single>=0&&c[i].value==value&&less(c[i],c[single]))single=i;
                }
                std::vector<Action> a;a.reserve(2+(build?0:2));
                if(single>=0)a.emplace_back(Action::SPILL,c[single].o,c[single].p);
                else {
                    for(int i:{best,second}) {
                        if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
                        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                    }
                }
                ++prefix2_plans;return a;
            }
        }
        ++sorted_plans;std::sort(c.begin(),c.begin()+n,less);
        int take=0;int64_t freed=0;double value=0;
        while(take<n&&freed<deficit){freed+=c[take].bytes;value+=c[take].value;++take;}
        if(rule==4||rule==8) {
            int single=-1;for(int i=0;i<n;++i)if(c[i].bytes>=deficit&&c[i].value<value){single=i;value=c[i].value;}
            if(single>=0){std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[single].o,c[single].p);return a;}
        }
        std::vector<Action> a;a.reserve(take+(build?0:2));
        for(int i=0;i<take;++i)if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
        return a;
    }
    static int64_t written(const SystemState& s,const std::vector<Action>& a) {
        int64_t n=0;for(const auto& x:a)if(x.type==Action::SPILL)n+=s.operators[x.op_id].partitions[x.partition_id].data_size;return n;
    }
    // Local certificate: any resident x with size(x)>M-size(B) MUST leave
    // before B can be loaded. Only prefetch when these forced victims suffice.
    bool forced(const SystemState& s,int o,int p,int64_t need,std::vector<Action>& a,int64_t freed) {
        if(!(flags_&2)||need<s.memory_limit/2)return false;
        int64_t deficit=need-(s.memory_limit-s.memory_used+freed);if(deficit<=0)return true;
        std::array<bool,512> removed{};
        for(const auto& x:a)if(x.type==Action::SPILL)removed[x.op_id*s.num_partitions+x.partition_id]=true;
        std::vector<Action> extra;int64_t sum=0;
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            if(x.in_memory&&x.data_size>s.memory_limit-need&&!removed[op.op_id*s.num_partitions+x.partition_id]&&!(op.op_id==o&&x.partition_id==p)) {
                extra.emplace_back(Action::SPILL,op.op_id,x.partition_id);sum+=x.data_size;
            }
        }
        if(sum<deficit)return false;
        a.insert(a.end(),extra.begin(),extra.end());++certified_prefetches;return true;
    }
public:

    void forceNext(int x){forced_next_=x;}
    void setMode(int x){policy_mode_=x;}
    int lastExpert() const{return selected_expert_;}
    uint64_t inferenceCount() const{return inferences_;}
    std::array<float,32> features(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
        std::array<float,32> f{};double m=double(s.memory_limit),sum=0,sq=0,mx=0,mn=m,bld=0,prb=0,own=0,total=0,own_total=0,heat=0;int nr=0;
        uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions){
            total+=x.data_size;if(op.op_id==o)own_total+=x.data_size;
            if(!x.in_memory||x.data_size<=0)continue;
            double z=double(x.data_size);sum+=z;sq+=z*z;mx=std::max(mx,z);mn=std::min(mn,z);++nr;
            if(op.phase==Phase::BUILD)bld+=z;else prb+=z;if(op.op_id==o)own+=z;
            int id=op.op_id*s.num_partitions+x.partition_id;uint64_t age=now>last_[id]?now-last_[id]:0;
            heat+=double(heat_[id])/(1.0+double(age)/64.0);
        }
        double free=double(s.memory_limit-s.memory_used),size=double(bytes),q=double(s.operators.size()*s.num_partitions);
        const auto& target=s.operators[o].partitions[p];int tid=o*s.num_partitions+p;uint64_t age=now>last_[tid]?now-last_[tid]:0;
        double h=double(heat_[tid])/(1.0+double(age)/64.0),avg=heat/std::max(1,nr);
        f[0]=float(s.memory_used/m);f[1]=float(size/m);f[2]=float(std::max(0.0,size-free)/m);f[3]=float(free/m);
        f[4]=float(s.operators.size()/8.0);f[5]=float(s.num_partitions/64.0);f[6]=float(build);f[7]=float(s.operators[o].phase==Phase::PROBE);
        f[8]=float(nr/q);f[9]=float(mx/m);f[10]=nr?float(mn/m):0;f[11]=float(sum/std::max(1,nr)/m);
        f[12]=float(sq/(sum*sum+1.0));f[13]=float(bld/m);f[14]=float(prb/m);f[15]=float(own/m);f[16]=float(bounded(own_total/(8*m)));
        bool pn=s.next_op.type=="PROBE",in=s.next_op.type=="INSERT";f[17]=float(pn);f[18]=float(in);
        if(pn||in){int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& nx=s.operators[no].partitions[np];
            f[19]=float(nx.data_size/m);f[20]=float(nx.in_memory);f[21]=float(no==o);f[22]=float((build?target.data_size+size:size)+nx.data_size<=m);}
        f[23]=float(s.write_bandwidth/10000.0);f[24]=float(s.read_bandwidth/10000.0);
        f[25]=float(double(s.miss_count)/double(std::max(uint64_t(1),now)));
        f[26]=float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_))));
        f[27]=float(h/(1+h));f[28]=float(avg/(1+avg));f[29]=float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),now-epoch_))));
        f[30]=float(selected_expert_/7.0);f[31]=float(total/(m*q));return f;
    }
    uint64_t joint_loads=0,joint_rejections=0,prefix2_plans=0;
    uint64_t interference_returns=0;
    void externalSpill(){spilled_=true;}
    uint64_t switches=0,epochs=0,allocations=0,cross_spills=0,linear_plans=0,sorted_plans=0,advanced_builds=0,certified_prefetches=0;
    explicit MySpillScheduler(int mode=-1):policy_mode_(mode),flags_(351),options_(105){}
    int selectedMode() const {return rule_;}
    std::vector<Action> onMemoryOverflow(const SystemState& s,int o,int p,int64_t bytes) override {
        choose(s,o,p,true,bytes);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+bytes;auto a=plan(s,bytes,o,p,true);spilled_=true;remember(s,a,-1);return a;
    }
    std::vector<Action> onPartitionMiss(const SystemState& s,int o,int p) override {
        choose(s,o,p,false,s.operators[o].partitions[p].data_size);requester_=o;++load_demands_;loaded(s,o,p);adapt(s,o,p);observe(o*s.num_partitions+p,o,tick(s));observeNext(s);
        int64_t size=s.operators[o].partitions[p].data_size;demand_size_=size;
        if((options_&1)&&probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            int64_t limit=(options_&2)?s.memory_limit/2:((options_&16)?s.memory_limit*3/4:s.memory_limit);
            if(s.operators[no].phase==Phase::PROBE&&!b.in_memory&&!(no==o&&np==p)&&size+b.data_size<=limit&&
                (!(options_&64)||(activeRule(false)==6&&size+b.data_size<=s.memory_limit/2&&std::max(size,b.data_size)<=2*std::min(size,b.data_size)))) {
                auto a=plan(s,size+b.data_size,o,p,false);
                bool accept=true;
                int64_t tolerance=std::max(int64_t(16),(size+b.data_size)/256),sum=0;
                if(options_&(32|64))for(const auto& v:a){
                    int64_t bytes=s.operators[v.op_id].partitions[v.partition_id].data_size;sum+=bytes;
                    if(bytes>((options_&64)?std::max(size,b.data_size)+tolerance:size+b.data_size))accept=false;
                }
                if((options_&64)&&sum>size+b.data_size+tolerance)accept=false;
                if(accept){
                    if(options_&64){
                        int64_t prefix=0,needed=size-(s.memory_limit-s.memory_used);
                        for(const auto& v:a){if(prefix>=needed)break;prefix+=s.operators[v.op_id].partitions[v.partition_id].data_size;}
                        if(s.memory_limit-s.memory_used+prefix<size+b.data_size)++compensated_misses_;
                    }
                    if(a.capacity()<a.size()+2)a.reserve(a.size()+2);
                    a.emplace_back(Action::LOAD,no,np);a.emplace_back(Action::LOAD,o,p);
                    ++load_demands_;++joint_loads;demand_size_=size+b.data_size;remember(s,a,creditRule());return a;
                }
                ++joint_rejections;
            }
        }
        auto a=plan(s,size,o,p,false);if(a.capacity()<a.size()+2)a.reserve(a.size()+2);int64_t freed=written(s,a);
        if(probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            if(s.operators[no].phase==Phase::PROBE&&!(no==o&&np==p)&&size+b.data_size<=s.memory_limit) {
                bool evicts=false;for(const auto& x:a)if(x.op_id==no&&x.partition_id==np)evicts=true;
                if(b.in_memory&&evicts) {
                    auto other=plan(s,size,o,p,false,no,np);int64_t f=written(s,other);
                    if(double(f-freed)/s.write_bandwidth<=double(b.data_size)/s.read_bandwidth+1.0){a.swap(other);freed=f;}
                }
                // Forced-victim prefetch is used at periodic callbacks only.
                // Here the existing no-extra-spill joint load remains cheaper.
                if(!b.in_memory&&s.memory_used-freed+size+b.data_size<=s.memory_limit){a.emplace_back(Action::LOAD,no,np);++load_demands_;}
            }
        }
        a.emplace_back(Action::LOAD,o,p);remember(s,a,creditRule());return a;
    }
    std::vector<Action> onPeriodicAdjust(const SystemState& s) override {
        if((flags_&1)&&s.next_op.type=="INSERT") {
            int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
            if(s.operators[o].partitions[p].in_memory&&s.next_op.tuple_size>s.memory_limit-s.memory_used) {
                choose(s,o,p,true,s.next_op.tuple_size);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+s.next_op.tuple_size;
                // PERIODIC_ADMISSION_V1: fixed next INSERT, immediate writes only.
                const int64_t admission_size=s.operators[o].partitions[p].data_size;
                const int64_t admission_tuple=s.next_op.tuple_size;
                const int64_t admission_factor=int64_t(1)<<2;
                if(admission_size>0&&admission_tuple>0&&admission_tuple<=s.memory_limit&&
                   admission_size<=s.memory_limit-admission_tuple) {
                    const int64_t admission_full=admission_size+admission_tuple;
                    if(admission_full<=s.memory_limit/admission_factor) {
                        const int64_t admission_cutoff=admission_full*admission_factor;
                        bool admission_has_other=false,admission_certified=true;
                        for(const auto& admission_op:s.operators) {
                            for(const auto& admission_part:admission_op.partitions) {
                                if(!admission_part.in_memory||admission_part.data_size<=0||
                                   (admission_op.op_id==o&&admission_part.partition_id==p))continue;
                                admission_has_other=true;
                                if(admission_part.data_size<admission_cutoff) {
                                    admission_certified=false;break;
                                }
                            }
                            if(!admission_certified)break;
                        }
                        if(admission_has_other&&admission_certified) {
                            std::vector<Action> admission_actions;admission_actions.reserve(1);
                            admission_actions.emplace_back(Action::SPILL,o,p);
                            spilled_=true;remember(s,admission_actions,-1);++advanced_builds;return admission_actions;
                        }
                    }
                }
                auto a=plan(s,s.next_op.tuple_size,o,p,true);spilled_=true;remember(s,a,-1);++advanced_builds;return a;
            }
            return {};
        }
        if(!spilled_||!probeNext(s))return {};
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);const auto& x=s.operators[o].partitions[p];
        if(s.operators[o].phase!=Phase::PROBE)return {};
        observe(o*s.num_partitions+p,o,tick(s)+1);
        if(x.in_memory)return {};
        requester_=o;demand_size_=x.data_size;std::vector<Action> a;
        if(x.data_size<=s.memory_limit-s.memory_used||forced(s,o,p,x.data_size,a,0)) {
            ++load_demands_;a.emplace_back(Action::LOAD,o,p);remember(s,a,-1);return a;
        }
        return {};
    }
};
