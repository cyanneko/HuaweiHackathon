#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <algorithm>
#include <cstdint>
#include <cassert>
#include <sstream>
#include <iomanip>
#include <chrono>
#include <memory>
#include <tuple>

/* ===== 数据结构定义 ===== */

enum class Phase { BUILD, PROBE };

struct PartitionState {
    int partition_id;
    int64_t data_size;   // 当前数据总大小（字节）
    bool in_memory;      // 是否在内存中
    PartitionState() : partition_id(-1), data_size(0), in_memory(true) {}
};

struct OperatorState {
    int op_id;
    Phase phase;
    std::vector<PartitionState> partitions;  // P个分区
};

struct PendingOp {
    std::string type;      // "INSERT" / "SWITCH" / "PROBE" / ""（无后续操作）
    int op_id;             // 算子ID，type为空时无意义
    int64_t key;           // INSERT/PROBE时的key，SWITCH时无意义
    int64_t tuple_size;    // INSERT时的元组大小，其余操作无意义
    PendingOp() : op_id(-1), key(0), tuple_size(0) {}
};

struct SystemState {
    int64_t memory_used;
    int64_t memory_limit;
    int num_partitions;
    double write_bandwidth;    // 字节/微秒
    double read_bandwidth;     // 字节/微秒
    int64_t hit_count;
    int64_t miss_count;
    int64_t total_io_bytes;
    std::vector<OperatorState> operators;
    PendingOp next_op;         // 下一个待处理操作
};

/* ===== 调度动作 ===== */

struct Action {
    enum Type { SPILL, LOAD } type;
    int op_id;
    int partition_id;
    Action(Type t, int o, int p) : type(t), op_id(o), partition_id(p) {}
};

/* ===== 调度器抽象基类 ===== */

class SpillScheduler {
public:
    virtual ~SpillScheduler() = default;

    // 场景1：INSERT导致内存溢出时调用
    virtual std::vector<Action> onMemoryOverflow(
        const SystemState& state,
        int op_id, int partition_id, int64_t tuple_size) = 0;

    // 场景2：PROBE需要加载磁盘分区时调用
    virtual std::vector<Action> onPartitionMiss(
        const SystemState& state,
        int op_id, int partition_id) = 0;

    // 场景3：周期性调度，每处理B个操作后调用
    virtual std::vector<Action> onPeriodicAdjust(
        const SystemState& state) = 0;
};

/* ===== 朴素调度器（基线实现）===== */

class NaiveSpillScheduler : public SpillScheduler {
public:
    // 内存溢出时：选择最大的in_memory分区落盘，直到释放足够空间
    std::vector<Action> onMemoryOverflow(
        const SystemState& state,
        int op_id, int partition_id, int64_t tuple_size) override {

        std::vector<Action> actions;
        int64_t needed = tuple_size;
        int64_t available = state.memory_limit - state.memory_used;

        // 收集所有in_memory分区，按data_size降序排列（排除当前正在插入的目标分区）
        std::vector<std::tuple<int64_t, int, int>> candidates;
        for (const auto& op : state.operators) {
            for (const auto& part : op.partitions) {
                if (part.in_memory && part.data_size > 0 &&
                    !(op.op_id == op_id && part.partition_id == partition_id)) {
                    candidates.emplace_back(part.data_size, op.op_id, part.partition_id);
                }
            }
        }
        std::sort(candidates.begin(), candidates.end(),
                  [](const auto& a, const auto& b) { return std::get<0>(a) > std::get<0>(b); });

        for (const auto& cand : candidates) {
            if (available >= needed) break;
            int64_t sz = std::get<0>(cand);
            int oid = std::get<1>(cand);
            int pid = std::get<2>(cand);
            actions.emplace_back(Action::SPILL, oid, pid);
            available += sz;
        }
        return actions;
    }

    // Probe未命中时：选择最大的in_memory分区落盘腾出空间，然后加载目标分区
    std::vector<Action> onPartitionMiss(
        const SystemState& state,
        int op_id, int partition_id) override {

        std::vector<Action> actions;
        int64_t needed = state.operators[op_id].partitions[partition_id].data_size;
        int64_t available = state.memory_limit - state.memory_used;

        if (available < needed) {
            std::vector<std::tuple<int64_t, int, int>> candidates;
            for (const auto& op : state.operators) {
                for (const auto& part : op.partitions) {
                    if (part.in_memory && part.data_size > 0 &&
                        !(op.op_id == op_id && part.partition_id == partition_id)) {
                        candidates.emplace_back(part.data_size, op.op_id, part.partition_id);
                    }
                }
            }
            std::sort(candidates.begin(), candidates.end(),
                      [](const auto& a, const auto& b) { return std::get<0>(a) > std::get<0>(b); });

            for (const auto& cand : candidates) {
                if (available >= needed) break;
                int64_t sz = std::get<0>(cand);
                int oid = std::get<1>(cand);
                int pid = std::get<2>(cand);
                actions.emplace_back(Action::SPILL, oid, pid);
                available += sz;
            }
        }

        actions.emplace_back(Action::LOAD, op_id, partition_id);
        return actions;
    }

    // 朴素策略：不做主动调整
    std::vector<Action> onPeriodicAdjust(const SystemState& state) override {
        return {};
    }
};

#include <stdexcept>
#define MySpillScheduler NeuralReference
#include "../MySpillScheduler_neural.cpp"
#undef MySpillScheduler
#define MySpillScheduler PreviousReference
#include "../MySpillScheduler_final.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_0
#include "mlp_full108_mlp1_absolute_h16_s20261030.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_1
#include "mlp_full108_mlp1_absolute_h16_s20261031.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_2
#include "mlp_full108_mlp1_absolute_h8_s20261030.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_3
#include "mlp_full108_mlp1_absolute_h8_s20261031.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_4
#include "mlp_full108_mlp1_relative_h16_s20261030.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_5
#include "mlp_full108_mlp1_relative_h16_s20261031.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_6
#include "mlp_full108_mlp1_relative_h8_s20261030.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_7
#include "mlp_full108_mlp1_relative_h8_s20261031.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_8
#include "tree_admission_r8_92_s0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_9
#include "tree_admission_r8_92_s1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_10
#include "tree_admission_r8_92_s2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_11
#include "tree_admission_r8_92_s3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_12
#include "tree_all_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_13
#include "tree_all_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_14
#include "tree_all_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_15
#include "tree_all_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_16
#include "tree_all_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_17
#include "tree_all_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_18
#include "tree_bound_all_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_19
#include "tree_bound_cheap_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_20
#include "tree_bound_cheap_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_21
#include "tree_bound_neural.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_22
#include "tree_category_full108_r1_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_23
#include "tree_category_full108_r1_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_24
#include "tree_category_full108_r1_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_25
#include "tree_category_full108_r1_3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_26
#include "tree_category_full108_r1_4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_27
#include "tree_category_full108_r1_5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_28
#include "tree_category_full108_r1_6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_29
#include "tree_category_full108_r1_7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_30
#include "tree_cheap_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_31
#include "tree_cheap_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_32
#include "tree_cheap_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_33
#include "tree_cheap_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_34
#include "tree_cheap_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_35
#include "tree_cheap_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_36
#include "tree_combine_g1_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_37
#include "tree_combine_g1_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_38
#include "tree_combine_g1_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_39
#include "tree_combine_g2_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_40
#include "tree_combine_g2_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_41
#include "tree_combine_g2_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_42
#include "tree_exactcredit_exact142_r1_s0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_43
#include "tree_exactcredit_exact142_r1_s1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_44
#include "tree_exactcredit_exact142_r1_s2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_45
#include "tree_fixed_shared113_e0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_46
#include "tree_fixed_shared113_e1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_47
#include "tree_fixed_shared113_e2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_48
#include "tree_fixed_shared113_e3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_49
#include "tree_fixed_shared113_e4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_50
#include "tree_fixed_shared113_e5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_51
#include "tree_fixed_shared113_e6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_52
#include "tree_fixed_shared113_e7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_53
#include "tree_full108_r1_cheap_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_54
#include "tree_full108_r1_cheap_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_55
#include "tree_full108_r1_cheap_absolute_d5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_56
#include "tree_full108_r1_cheap_absolute_d6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_57
#include "tree_full108_r1_cheap_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_58
#include "tree_full108_r1_cheap_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_59
#include "tree_full108_r1_cheap_relative_d5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_60
#include "tree_full108_r1_cheap_relative_d6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_61
#include "tree_nextcredit_next113_r1_s0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_62
#include "tree_nextcredit_next113_r1_s1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_63
#include "tree_nextcredit_next113_r1_s2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_64
#include "tree_refine_r5_60_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_65
#include "tree_refine_r5_60_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_66
#include "tree_refine_r5_60_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_67
#include "tree_refine_r5_60_3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_68
#include "tree_refine_r5_60_4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_69
#include "tree_refine_r5_60_5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_70
#include "tree_refine_r5_60_6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_71
#include "tree_refine_r5_60_7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_72
#include "tree_refine_r6_gate60_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_73
#include "tree_refine_r6_gate60_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_74
#include "tree_refine_r6_gate60_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_75
#include "tree_refine_r6_gate60_3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_76
#include "tree_refine_r6_gate60_4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_77
#include "tree_refine_r6_gate60_5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_78
#include "tree_refine_r6_gate60_6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_79
#include "tree_refine_r6_gate60_7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_80
#include "tree_scratch_search_g1_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_81
#include "tree_search_g0_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_82
#include "tree_search_g0_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_83
#include "tree_search_g0_10.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_84
#include "tree_search_g0_11.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_85
#include "tree_search_g0_12.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_86
#include "tree_search_g0_13.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_87
#include "tree_search_g0_14.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_88
#include "tree_search_g0_15.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_89
#include "tree_search_g0_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_90
#include "tree_search_g0_3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_91
#include "tree_search_g0_4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_92
#include "tree_search_g0_5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_93
#include "tree_search_g0_6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_94
#include "tree_search_g0_7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_95
#include "tree_search_g0_8.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_96
#include "tree_search_g0_9.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_97
#include "tree_search_g1_0.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_98
#include "tree_search_g1_1.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_99
#include "tree_search_g1_10.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_100
#include "tree_search_g1_11.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_101
#include "tree_search_g1_12.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_102
#include "tree_search_g1_13.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_103
#include "tree_search_g1_14.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_104
#include "tree_search_g1_15.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_105
#include "tree_search_g1_2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_106
#include "tree_search_g1_3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_107
#include "tree_search_g1_4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_108
#include "tree_search_g1_5.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_109
#include "tree_search_g1_6.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_110
#include "tree_search_g1_7.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_111
#include "tree_search_g1_8.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_112
#include "tree_search_g1_9.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_113
#include "tree_v2_all_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_114
#include "tree_v2_all_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_115
#include "tree_v2_all_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_116
#include "tree_v2_all_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_117
#include "tree_v2_all_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_118
#include "tree_v2_all_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_119
#include "tree_v2_cheap_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_120
#include "tree_v2_cheap_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_121
#include "tree_v2_cheap_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_122
#include "tree_v2_cheap_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_123
#include "tree_v2_cheap_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_124
#include "tree_v2_cheap_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_125
#include "tree_v3_all_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_126
#include "tree_v3_all_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_127
#include "tree_v3_all_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_128
#include "tree_v3_all_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_129
#include "tree_v3_all_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_130
#include "tree_v3_all_relative_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_131
#include "tree_v3_cheap_absolute_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_132
#include "tree_v3_cheap_absolute_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_133
#include "tree_v3_cheap_absolute_d4.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_134
#include "tree_v3_cheap_relative_d2.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_135
#include "tree_v3_cheap_relative_d3.cpp"
#undef MySpillScheduler
#define MySpillScheduler Tree_136
#include "tree_v3_cheap_relative_d4.cpp"
#undef MySpillScheduler
static std::unique_ptr<SpillScheduler> makeScheduler(int mode){switch(mode){case 0:return std::make_unique<NeuralReference>();case 1:return std::make_unique<PreviousReference>();case 2:return std::make_unique<NaiveSpillScheduler>();case 126:return std::make_unique<Tree_0>();case 127:return std::make_unique<Tree_1>();case 128:return std::make_unique<Tree_2>();case 129:return std::make_unique<Tree_3>();case 130:return std::make_unique<Tree_4>();case 131:return std::make_unique<Tree_5>();case 132:return std::make_unique<Tree_6>();case 133:return std::make_unique<Tree_7>();case 98:return std::make_unique<Tree_8>();case 99:return std::make_unique<Tree_9>();case 108:return std::make_unique<Tree_10>();case 109:return std::make_unique<Tree_11>();case 3:return std::make_unique<Tree_12>();case 4:return std::make_unique<Tree_13>();case 5:return std::make_unique<Tree_14>();case 6:return std::make_unique<Tree_15>();case 7:return std::make_unique<Tree_16>();case 8:return std::make_unique<Tree_17>();case 15:return std::make_unique<Tree_18>();case 16:return std::make_unique<Tree_19>();case 17:return std::make_unique<Tree_20>();case 18:return std::make_unique<Tree_21>();case 110:return std::make_unique<Tree_22>();case 111:return std::make_unique<Tree_23>();case 112:return std::make_unique<Tree_24>();case 113:return std::make_unique<Tree_25>();case 114:return std::make_unique<Tree_26>();case 115:return std::make_unique<Tree_27>();case 116:return std::make_unique<Tree_28>();case 117:return std::make_unique<Tree_29>();case 9:return std::make_unique<Tree_30>();case 10:return std::make_unique<Tree_31>();case 11:return std::make_unique<Tree_32>();case 12:return std::make_unique<Tree_33>();case 13:return std::make_unique<Tree_34>();case 14:return std::make_unique<Tree_35>();case 75:return std::make_unique<Tree_36>();case 76:return std::make_unique<Tree_37>();case 77:return std::make_unique<Tree_38>();case 78:return std::make_unique<Tree_39>();case 79:return std::make_unique<Tree_40>();case 80:return std::make_unique<Tree_41>();case 145:return std::make_unique<Tree_42>();case 146:return std::make_unique<Tree_43>();case 147:return std::make_unique<Tree_44>();case 134:return std::make_unique<Tree_45>();case 135:return std::make_unique<Tree_46>();case 136:return std::make_unique<Tree_47>();case 137:return std::make_unique<Tree_48>();case 138:return std::make_unique<Tree_49>();case 139:return std::make_unique<Tree_50>();case 140:return std::make_unique<Tree_51>();case 141:return std::make_unique<Tree_52>();case 118:return std::make_unique<Tree_53>();case 119:return std::make_unique<Tree_54>();case 120:return std::make_unique<Tree_55>();case 121:return std::make_unique<Tree_56>();case 122:return std::make_unique<Tree_57>();case 123:return std::make_unique<Tree_58>();case 124:return std::make_unique<Tree_59>();case 125:return std::make_unique<Tree_60>();case 142:return std::make_unique<Tree_61>();case 143:return std::make_unique<Tree_62>();case 144:return std::make_unique<Tree_63>();case 82:return std::make_unique<Tree_64>();case 83:return std::make_unique<Tree_65>();case 84:return std::make_unique<Tree_66>();case 85:return std::make_unique<Tree_67>();case 86:return std::make_unique<Tree_68>();case 87:return std::make_unique<Tree_69>();case 88:return std::make_unique<Tree_70>();case 89:return std::make_unique<Tree_71>();case 90:return std::make_unique<Tree_72>();case 91:return std::make_unique<Tree_73>();case 92:return std::make_unique<Tree_74>();case 93:return std::make_unique<Tree_75>();case 94:return std::make_unique<Tree_76>();case 95:return std::make_unique<Tree_77>();case 96:return std::make_unique<Tree_78>();case 97:return std::make_unique<Tree_79>();case 81:return std::make_unique<Tree_80>();case 43:return std::make_unique<Tree_81>();case 44:return std::make_unique<Tree_82>();case 45:return std::make_unique<Tree_83>();case 46:return std::make_unique<Tree_84>();case 47:return std::make_unique<Tree_85>();case 48:return std::make_unique<Tree_86>();case 49:return std::make_unique<Tree_87>();case 50:return std::make_unique<Tree_88>();case 51:return std::make_unique<Tree_89>();case 52:return std::make_unique<Tree_90>();case 53:return std::make_unique<Tree_91>();case 54:return std::make_unique<Tree_92>();case 55:return std::make_unique<Tree_93>();case 56:return std::make_unique<Tree_94>();case 57:return std::make_unique<Tree_95>();case 58:return std::make_unique<Tree_96>();case 59:return std::make_unique<Tree_97>();case 60:return std::make_unique<Tree_98>();case 61:return std::make_unique<Tree_99>();case 62:return std::make_unique<Tree_100>();case 63:return std::make_unique<Tree_101>();case 64:return std::make_unique<Tree_102>();case 65:return std::make_unique<Tree_103>();case 66:return std::make_unique<Tree_104>();case 67:return std::make_unique<Tree_105>();case 68:return std::make_unique<Tree_106>();case 69:return std::make_unique<Tree_107>();case 70:return std::make_unique<Tree_108>();case 71:return std::make_unique<Tree_109>();case 72:return std::make_unique<Tree_110>();case 73:return std::make_unique<Tree_111>();case 74:return std::make_unique<Tree_112>();case 19:return std::make_unique<Tree_113>();case 20:return std::make_unique<Tree_114>();case 21:return std::make_unique<Tree_115>();case 22:return std::make_unique<Tree_116>();case 23:return std::make_unique<Tree_117>();case 24:return std::make_unique<Tree_118>();case 25:return std::make_unique<Tree_119>();case 26:return std::make_unique<Tree_120>();case 27:return std::make_unique<Tree_121>();case 28:return std::make_unique<Tree_122>();case 29:return std::make_unique<Tree_123>();case 30:return std::make_unique<Tree_124>();case 31:return std::make_unique<Tree_125>();case 32:return std::make_unique<Tree_126>();case 33:return std::make_unique<Tree_127>();case 34:return std::make_unique<Tree_128>();case 35:return std::make_unique<Tree_129>();case 36:return std::make_unique<Tree_130>();case 37:return std::make_unique<Tree_131>();case 38:return std::make_unique<Tree_132>();case 39:return std::make_unique<Tree_133>();case 40:return std::make_unique<Tree_134>();case 41:return std::make_unique<Tree_135>();case 42:return std::make_unique<Tree_136>();default:if(mode>=100&&mode<108)return std::make_unique<NeuralReference>(mode-100);throw std::runtime_error("mode");}}
/* ===== 执行引擎 ===== */

class HashJoinEngine {
private:
    int64_t memory_limit_;
    int num_partitions_;
    double write_bandwidth_;
    double read_bandwidth_;
    int miss_penalty_;
    int periodic_interval_;

    int64_t memory_used_;
    int64_t hit_count_;
    int64_t miss_count_;
    double total_io_time_;
    double total_decision_time_;   // 调度器决策CPU耗时累计（微秒）
    int64_t total_io_bytes_;
    int operation_count_;

    std::vector<OperatorState> operators_;
    std::unique_ptr<SpillScheduler> scheduler_;
    PendingOp next_op_;  // 预存下一个操作，供getSystemState使用

    SystemState getSystemState() const {
        SystemState state;
        state.memory_used = memory_used_;
        state.memory_limit = memory_limit_;
        state.num_partitions = num_partitions_;
        state.write_bandwidth = write_bandwidth_;
        state.read_bandwidth = read_bandwidth_;
        state.hit_count = hit_count_;
        state.miss_count = miss_count_;
        state.total_io_bytes = total_io_bytes_;
        state.operators = operators_;
        state.next_op = next_op_;
        return state;
    }

    // 测量并累加一次调度器调用的CPU耗时（微秒）
    template<typename F>
    auto timedSchedulerCall(F&& f) -> decltype(f()) {
        auto t_start = std::chrono::high_resolution_clock::now();
        auto result = f();
        auto t_end = std::chrono::high_resolution_clock::now();
        double us = std::chrono::duration<double, std::micro>(t_end - t_start).count();
        total_decision_time_ += us;
        return result;
    }

    void executeActions(const std::vector<Action>& actions) {
        for (const auto& act : actions) {
            auto& part = operators_[act.op_id].partitions[act.partition_id];
            if (act.type == Action::SPILL) {
                if (!part.in_memory || part.data_size == 0) continue;
                total_io_time_ += static_cast<double>(part.data_size) / write_bandwidth_;
                total_io_bytes_ += part.data_size;
                part.in_memory = false;
                memory_used_ -= part.data_size;
            } else if (act.type == Action::LOAD) {
                // 引擎静默忽略非法 LOAD：对 in_memory 分区、或 BUILD 阶段算子的分区
                if (part.in_memory) continue;
                if (operators_[act.op_id].phase == Phase::BUILD) continue;
                if (memory_used_ + part.data_size > memory_limit_) {
                    std::cerr << "OOM: LOAD would exceed memory limit" << std::endl;
                    std::exit(1);
                }
                total_io_time_ += static_cast<double>(part.data_size) / read_bandwidth_;
                total_io_bytes_ += part.data_size;
                part.in_memory = true;
                memory_used_ += part.data_size;
            }
        }
    }

public:
    HashJoinEngine(int64_t memory_limit, int num_partitions,
                   double write_bandwidth, double read_bandwidth,
                   int miss_penalty, int periodic_interval,
                   std::unique_ptr<SpillScheduler> scheduler)
        : memory_limit_(memory_limit), num_partitions_(num_partitions),
          write_bandwidth_(write_bandwidth), read_bandwidth_(read_bandwidth),
          miss_penalty_(miss_penalty), periodic_interval_(periodic_interval),
          memory_used_(0), hit_count_(0), miss_count_(0),
          total_io_time_(0.0), total_decision_time_(0.0),
          total_io_bytes_(0), operation_count_(0),
          scheduler_(std::move(scheduler)) {}

    void addOperator(int op_id) {
        OperatorState op;
        op.op_id = op_id;
        op.phase = Phase::BUILD;
        op.partitions.resize(num_partitions_);
        for (int i = 0; i < num_partitions_; ++i) {
            op.partitions[i].partition_id = i;
        }
        operators_.push_back(op);
    }

    // 设置下一个待处理操作（由main循环在执行当前操作前调用）
    void setNextOp(const PendingOp& op) { next_op_ = op; }

    void processInsert(int op_id, int64_t key, int64_t tuple_size) {
        int pid = key % num_partitions_;
        auto& part = operators_[op_id].partitions[pid];

        if (part.in_memory) {
            if (memory_used_ + tuple_size > memory_limit_) {
                // 内存溢出，调用调度器（计时）
                auto actions = timedSchedulerCall([&]() {
                    return scheduler_->onMemoryOverflow(
                        getSystemState(), op_id, pid, tuple_size);
                });
                executeActions(actions);
                // 校验：调度器释放的空间是否足够
                if (memory_used_ + tuple_size > memory_limit_) {
                    std::cerr << "OOM: scheduler failed to free enough memory for INSERT" << std::endl;
                    std::exit(1);
                }
            }
            part.data_size += tuple_size;
            memory_used_ += tuple_size;
        } else {
            // 分区在磁盘上，元组直接写磁盘
            total_io_time_ += static_cast<double>(tuple_size) / write_bandwidth_;
            total_io_bytes_ += tuple_size;
            part.data_size += tuple_size;
        }

        operation_count_++;
        if (operation_count_ % periodic_interval_ == 0) {
            auto actions = timedSchedulerCall([&]() {
                return scheduler_->onPeriodicAdjust(getSystemState());
            });
            executeActions(actions);
        }
    }

    // SWITCH不计入operation_count_，不触发周期性调度
    void processSwitch(int op_id) {
        operators_[op_id].phase = Phase::PROBE;
    }

    void processProbe(int op_id, int64_t key) {
        int pid = key % num_partitions_;
        auto& part = operators_[op_id].partitions[pid];

        if (part.in_memory) {
            hit_count_++;
        } else {
            miss_count_++;
            // 调用调度器加载分区（计时）
            auto actions = timedSchedulerCall([&]() {
                return scheduler_->onPartitionMiss(
                    getSystemState(), op_id, pid);
            });
            executeActions(actions);
            // 校验：调度器必须将目标分区加载到内存
            if (!part.in_memory) {
                std::cerr << "OOM: scheduler failed to load target partition for PROBE" << std::endl;
                std::exit(1);
            }
        }

        operation_count_++;
        if (operation_count_ % periodic_interval_ == 0) {
            auto actions = timedSchedulerCall([&]() {
                return scheduler_->onPeriodicAdjust(getSystemState());
            });
            executeActions(actions);
        }
    }

    void printResult() const {
        double total_score = total_io_time_ +
            static_cast<double>(miss_penalty_) * miss_count_ + total_decision_time_;
        std::cout << std::fixed << std::setprecision(2);
        std::cout << "Total_IO_Time: " << total_io_time_ << std::endl;
        std::cout << "Total_Decision_Time: " << total_decision_time_ << std::endl;
        std::cout << "Hit_Count: " << hit_count_ << std::endl;
        std::cout << "Miss_Count: " << miss_count_ << std::endl;
        std::cout << "Total_Score: " << total_score << std::endl;
    }
};

/* ===== 主函数 ===== */

int main(int argc, char* argv[]) {
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <input_file>" << std::endl;
        return 1;
    }

    std::ifstream fin(argv[1]);
    if (!fin) {
        std::cerr << "Cannot open input file: " << argv[1] << std::endl;
        return 1;
    }

    int K, P, miss_penalty, N, B;
    int64_t M;
    double W, R;

    fin >> K >> P >> M >> W >> R >> miss_penalty;
    fin >> N >> B;

    auto scheduler = makeScheduler(argc>2?std::stoi(argv[2]):0);
    HashJoinEngine engine(M, P, W, R, miss_penalty, B, std::move(scheduler));

    for (int i = 0; i < K; ++i) {
        int op_id, build_count, probe_count;
        fin >> op_id >> build_count >> probe_count;
        engine.addOperator(op_id);
    }

    // 预读所有操作行
    std::vector<std::string> op_lines;
    {
        std::string line;
        std::getline(fin, line);  // consume newline
        for (int i = 0; i < N; ++i) {
            std::getline(fin, line);
            op_lines.push_back(line);
        }
    }

    for (int i = 0; i < N; ++i) {
        // 设置next_op为当前操作的下一条
        PendingOp next;
        if (i + 1 < N) {
            std::istringstream niss(op_lines[i + 1]);
            niss >> next.type;
            if (next.type == "INSERT") niss >> next.op_id >> next.key >> next.tuple_size;
            else if (next.type == "SWITCH") niss >> next.op_id;
            else if (next.type == "PROBE") niss >> next.op_id >> next.key;
        } else {
            next.type = "";  // 无后续操作
        }
        engine.setNextOp(next);

        // 执行当前操作
        std::istringstream iss(op_lines[i]);
        std::string op;
        iss >> op;

        if (op == "INSERT") {
            int op_id;
            int64_t key, size;
            iss >> op_id >> key >> size;
            engine.processInsert(op_id, key, size);
        } else if (op == "SWITCH") {
            int op_id;
            iss >> op_id;
            engine.processSwitch(op_id);
        } else if (op == "PROBE") {
            int op_id;
            int64_t key;
            iss >> op_id >> key;
            engine.processProbe(op_id, key);
        }
    }

    engine.printResult();
    return 0;
}

