// Single-file C++14 scheduler. Uses only SystemState, next_op and own history.
// Flags are for reproducible local ablations; the evaluator uses no arguments.
#include <algorithm>
#include <array>
#include <cstdint>
#include <vector>
#include <cmath>

class MySpillScheduler final : public SpillScheduler {
    // Inference sees only public state and scheduler-owned observations.
    int policy_mode_=-1,forced_next_=-1,selected_expert_=7;
    std::array<double,512> gds_{};double gds_clock_=0;
    uint64_t choices_=0,inferences_=0;
    static double bounded(double x){return std::max(0.0,std::min(1.0,x));}
    float cheapMlpTargetHeat(const SystemState& s,int o,int p) const {int id=o*s.num_partitions+p;uint64_t now=tick(s),age=now>last_[id]?now-last_[id]:0;double h=double(heat_[id])/(1.0+double(age)/64.0);return float(h/(1+h));}
static int cheapMlpDecision(const std::array<float,20>& numeric,int previous) {
    static constexpr float w1[16][20]={{2.29612207f,-0.240833595f,0.711329281f,-1.76046097f,-0.629985511f,-1.21364617f,-0.193958864f,-0.483166039f,1.61613667f,-1.05837929f,-0.0710294992f,-1.03644097f,0.391432464f,0.817292035f,0.552055836f,0.522369087f,1.07906282f,-0.0365368314f,-1.09397209f,-1.46787202f},{3.86623311f,2.00942492f,-0.36486724f,-1.76350451f,-2.22706532f,0.913414299f,-0.0864940211f,-0.422452837f,-0.993359447f,-0.951962948f,-0.288392872f,-0.315814167f,0.59482044f,1.30476201f,0.622627258f,1.13405204f,0.496741414f,0.274797201f,0.233480275f,-0.867429852f},{-1.08743966f,-1.09193945f,0.487413615f,-1.81037366f,-1.47982836f,0.630394936f,1.86812913f,-0.649726033f,1.37890732f,0.163052171f,-0.0864874721f,0.587454021f,0.209092855f,-0.368979394f,0.137296274f,1.48219562f,0.894817889f,0.57639432f,-0.499220014f,1.16166306f},{1.13583279f,1.35215008f,-0.954749405f,0.273316383f,0.329308927f,0.0912541226f,0.910054743f,0.53394711f,1.64578009f,-0.951003969f,-1.31209838f,-0.490100205f,0.571116805f,-0.803858042f,-2.31175137f,0.257124126f,-0.700548887f,-1.90748453f,-0.993158996f,0.986395955f},{2.33603382f,-0.692239344f,-1.61272418f,-0.833839536f,0.705576658f,1.52480316f,-0.305718809f,1.69680738f,1.48466253f,0.47681874f,-1.47031724f,-0.547204137f,-0.828436196f,-0.263484776f,-1.39858258f,-1.01091576f,0.883926034f,-0.0574532002f,-0.269725889f,0.203769952f},{0.248303771f,1.18196547f,-1.55620754f,-1.65901566f,0.542950809f,0.802487552f,-0.419103801f,-0.117390282f,-3.74570036f,1.48323774f,-0.893788457f,-0.375513554f,-0.0663112924f,-0.671208978f,0.0379850045f,0.988762081f,-1.06637394f,-0.435635388f,-1.14685655f,1.20274794f},{3.13618684f,-1.37971997f,-0.588018656f,-0.762081265f,0.800618589f,0.140120387f,-1.12409198f,1.15842259f,-0.750100434f,0.943974376f,-1.52392805f,0.33360672f,0.244504675f,1.36338711f,0.727425456f,-2.60334921f,-2.13062286f,-0.827486038f,0.42481634f,-0.261455178f},{2.31907177f,-2.79250383f,-4.14640474f,-2.34194231f,1.6277386f,0.944614589f,-2.50535607f,1.86355615f,2.05282831f,-1.94528055f,-1.999753f,0.201401994f,-0.48552677f,-0.313868344f,-1.43385541f,-1.66875029f,0.341283828f,-0.320475131f,-2.39177918f,-1.16670775f},{-0.477443337f,0.243158162f,-0.913441896f,2.38907099f,-0.0843831822f,-0.146788418f,0.369329363f,-2.3231225f,-0.501653194f,0.990330815f,3.45722866f,-0.202874303f,0.797248304f,-1.33934033f,-0.2181191f,-0.000535753148f,-0.24094446f,0.306893945f,0.62403053f,0.618388951f},{1.42940867f,0.30388689f,-3.18138337f,0.644985795f,0.360371798f,-1.23990464f,-3.01678872f,1.20325923f,2.51614594f,-1.00008786f,-1.30228877f,-0.981699705f,-0.261910051f,0.340374619f,0.881765783f,-0.0861912444f,0.611814201f,-1.33825922f,0.560701072f,2.53448725f},{-1.51804066f,-0.506462157f,-4.97120428f,-1.2711699f,0.971793711f,0.0516314954f,1.70347106f,-0.0518795215f,0.0139043489f,0.81070298f,0.223803788f,-1.49656487f,-0.380814463f,0.803978086f,-0.746203005f,-0.645999074f,2.16762948f,1.36814845f,0.316552252f,2.66570783f},{-3.22846079f,-1.1641202f,-2.92140722f,-1.30562031f,-0.865876913f,-0.138314322f,1.86802959f,1.51668644f,-0.477162063f,0.0390422978f,-0.392718375f,-1.05766797f,0.480708092f,-0.844908059f,1.0451448f,1.25967968f,0.919547498f,0.259777844f,0.698636889f,1.06590629f},{-0.470560163f,-0.0645447671f,-0.449186921f,0.732637763f,0.103674866f,0.0587326661f,-0.999220967f,1.0557636f,1.49567783f,-2.84772372f,-1.05736923f,-0.878502905f,0.917349935f,0.153064921f,-1.66076553f,-0.281019837f,1.85613716f,1.26578176f,-0.28288278f,1.09940982f},{0.242316216f,-1.27552664f,-0.556383312f,-3.18312287f,1.12823534f,0.490962058f,2.1239295f,-2.45427489f,-0.320956647f,0.47087431f,-1.18887293f,-0.486455142f,0.0340530798f,1.01489937f,0.213783398f,-0.0880673453f,1.6089319f,1.04518437f,0.716378093f,2.55659032f},{2.96413326f,-0.159158289f,2.30173326f,-0.811964214f,-1.38197899f,1.2707907f,-0.269093692f,-0.0649914742f,-0.308089316f,-0.0412424318f,0.263531685f,-0.713041484f,0.75810045f,0.692386568f,0.144135356f,0.0308641419f,0.629606485f,-0.229598939f,-0.0670133308f,1.38984108f},{0.374557316f,0.560226023f,-0.248003453f,0.818775058f,-1.67071486f,0.220346391f,1.20186734f,0.626308084f,-0.509213448f,0.620142639f,2.6389401f,-0.362161666f,-0.0934935063f,0.319929719f,0.398565978f,0.797394872f,0.170756891f,-0.72677356f,-1.67412817f,5.12469292f}};
    static constexpr float category[16][8]={{-2.54735343e-26f,0.159994751f,-0.739823818f,-0.270446628f,0.463501304f,0.396494925f,-0.933089256f,-0.317767888f},{3.06994581e-27f,0.58459866f,0.0940374061f,0.197817996f,0.166806653f,0.110653825f,-0.442610592f,0.0313042849f},{-1.87647052e-27f,0.295081794f,0.232738316f,-0.195835873f,-0.397206366f,0.181158036f,0.0818493962f,0.390004724f},{-3.14715565e-25f,0.231101498f,0.705305398f,-0.0657798797f,-0.504874349f,-0.0064115026f,0.0506871156f,-0.195859432f},{-3.0023288e-26f,-0.444759786f,-0.353852481f,0.0317718983f,-0.184090927f,-0.129595831f,0.135424644f,-0.393713653f},{-3.87460859e-27f,-0.177255735f,0.682249486f,0.0339806378f,0.716888666f,-0.518252373f,-0.0485988073f,0.213286355f},{-1.16569345e-23f,0.135733053f,0.730893016f,0.0353726521f,0.552879214f,-0.199004099f,0.0116261328f,-0.247361168f},{2.45879066e-27f,-0.294363022f,-0.218228817f,0.953147233f,0.725566626f,0.0554254539f,0.433468848f,-0.0965134427f},{2.38496873e-29f,-0.425616026f,-0.0395290703f,0.258994669f,0.760460734f,-0.0149853127f,-0.671872497f,-0.326376766f},{2.63941838e-28f,-0.0889755264f,0.0745908245f,-0.204622269f,0.0990367308f,0.312342823f,0.244607329f,5.39496009e-12f},{-1.77923803e-20f,0.49580732f,-0.121702984f,-0.147167116f,0.647404373f,-0.567195952f,0.738118649f,0.304945499f},{-1.10594794e-27f,0.258618265f,-0.413040459f,-0.371549398f,0.684734702f,-0.144897759f,-0.31190449f,-0.345540196f},{2.40780243e-27f,0.149835289f,0.138842896f,0.543180108f,-0.466724336f,0.330650568f,-0.222139329f,-1.16731576e-13f},{1.57543107e-20f,-0.110914864f,-0.353482425f,0.0835423023f,0.0799772218f,0.255676955f,0.477135807f,0.13428928f},{-8.87962819e-24f,0.358604908f,0.519624114f,0.0167120695f,0.268625021f,-0.188305393f,-0.495363444f,-0.0815245882f},{9.29387259e-21f,-0.34032622f,0.554308653f,0.898912668f,-0.15067187f,0.223074928f,-0.281207621f,0.435721815f}};
    static constexpr float b1[16]={-2.56408429f,-4.02433681f,-0.288836747f,-0.356405824f,-3.94077182f,4.73012686f,-2.50413513f,-2.35971785f,2.694911f,-3.39720941f,0.117387317f,2.321275f,-2.77439594f,-0.253535271f,-3.75919795f,-0.314902633f};
    static constexpr float w2[8][16]={{-0.0642235428f,0.0326223895f,-0.131929412f,-0.279703557f,0.149688065f,-0.146409646f,-0.117534935f,0.112519428f,-0.297636211f,0.0456599183f,0.161302552f,-0.345647067f,0.14814961f,0.196632057f,-0.199384689f,-0.0497736223f},{0.160321265f,0.172045022f,0.166583091f,0.0708221048f,-0.399135113f,-0.0120695485f,-0.288487375f,-0.221285328f,-0.113597617f,-0.0599451587f,-0.286206901f,0.0882716104f,-0.0974206924f,-0.0920330361f,0.148096964f,0.0559180938f},{0.0166994147f,-0.163946629f,-0.126271576f,0.00389263616f,0.106005423f,0.00244619581f,0.134531185f,0.0930607319f,0.0928498283f,0.217505127f,0.227178544f,0.160429671f,0.0856272578f,0.0904446393f,-0.0175425876f,-0.4621692f},{0.0593954697f,-0.103402011f,-0.0566081591f,-0.194274545f,-0.10350243f,0.0612428337f,0.182327077f,-0.0633333847f,-0.131944627f,-0.093289353f,-0.129149586f,-0.219967872f,0.214437604f,-0.181029037f,0.0508379564f,0.000801819144f},{-0.270310223f,0.042268578f,0.146597534f,-0.0239773914f,-0.405200869f,-0.0817094222f,-0.212949678f,-0.340521365f,0.102653794f,-0.0838023201f,-0.189626947f,0.0173624009f,-0.0733113959f,-0.181043193f,0.0713463947f,0.120002285f},{-0.201295644f,-0.0307380874f,-0.0392630771f,0.0516314991f,0.00106999907f,0.0682794973f,-0.0257227961f,-0.0142473755f,0.0473134927f,-0.161264345f,-0.188714907f,-0.0319639891f,-0.0688890368f,-0.109025195f,-0.136296615f,-0.06509047f},{0.110842384f,-0.0161833223f,-0.0775309876f,-0.0919895694f,-0.311013192f,-0.240482539f,-0.302632838f,-0.323069125f,0.0668907836f,-0.0345387273f,-0.152226761f,0.11839585f,-0.502700925f,-0.0949191973f,0.0520188622f,0.10554377f},{-0.270820796f,-0.208288476f,-0.0767873302f,0.066263251f,0.0549662784f,-0.011281535f,0.183163643f,0.159285367f,0.150576189f,-0.251940519f,-0.114813112f,-0.0266553517f,-0.128673971f,-0.296500087f,-0.25475347f,0.128245607f}};
    static constexpr float b2[8]={0.0758017004f,-0.100253426f,0.07224603f,0.0164893437f,-0.23766537f,-0.0162273012f,-0.179674491f,0.106658906f};
    if(previous<0||previous>=8)previous=7;
    std::array<float,16> activation;
    for(int j=0;j<16;++j){float value=b1[j];
        for(int i=0;i<20;++i){float product=w1[j][i]*numeric[i];value=float(value+product);}
        value=float(value+category[j][previous]);activation[j]=value>0.0f?value:0.0f;}
    int best=0;float best_value=0.0f;
    for(int e=0;e<8;++e){float value=b2[e];
        for(int j=0;j<16;++j){float product=w2[e][j]*activation[j];value=float(value+product);}
        if(e==0||value>best_value){best=e;best_value=value;}}return best;
}
int route(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
    const std::array<float,20> numeric={{float(double(s.memory_used)/double(s.memory_limit)),float(double(bytes)/double(s.memory_limit)),float(std::max(0.0,double(bytes)-double(s.memory_limit-s.memory_used))/double(s.memory_limit)),float(double(s.memory_limit-s.memory_used)/double(s.memory_limit)),float(s.operators.size()/8.0),float(s.num_partitions/64.0),float(build),float(s.operators[o].phase==Phase::PROBE),float(s.next_op.type=="PROBE"),float(s.next_op.type=="INSERT"),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size/double(s.memory_limit)):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].in_memory):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float(s.next_op.op_id==o):0.0f),((s.next_op.type=="PROBE"||s.next_op.type=="INSERT")?float((build?s.operators[o].partitions[p].data_size+double(bytes):double(bytes))+s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size<=double(s.memory_limit)):0.0f),float(s.write_bandwidth/10000.0),float(s.read_bandwidth/10000.0),float(double(s.miss_count)/double(std::max(uint64_t(1),tick(s)))),float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),tick(s)-epoch_)))),cheapMlpTargetHeat(s,o,p),float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),tick(s)-epoch_))))}};
    return cheapMlpDecision(numeric,selected_expert_);
}
#ifdef PORTFOLIO_AUDIT
int routeReference(const std::array<float,32>& x) const {
    const std::array<float,20> numeric={{x[0],x[1],x[2],x[3],x[4],x[5],x[6],x[7],x[17],x[18],x[19],x[20],x[21],x[22],x[23],x[24],x[25],x[26],x[27],x[29]}};
    int previous=int(double(x[30])*7.0+0.5);return cheapMlpDecision(numeric,previous);
}
#endif

    int activeRule(bool build) const {
        static const int rules[8]={0,8,3,6,4,9,4,4};
        return selected_expert_==7?(build?0:rule_):((selected_expert_==6&&build)?0:rules[selected_expert_]);
    }
    int creditRule() const {int r=activeRule(false);return (r==3||r==4||r==6)?r:-1;}
    void choose(const SystemState& s,int o,int p,bool build,int64_t bytes) {
        if(forced_next_>=0){selected_expert_=forced_next_;forced_next_=-1;}
        else if(policy_mode_>=0)selected_expert_=policy_mode_;
        else if(policy_mode_==-2)selected_expert_=int((tick(s)*6364136223846793005ULL+choices_*1442695040888963407ULL)%8);
        else {int next_expert=route(s,o,p,build,bytes);
#ifdef PORTFOLIO_AUDIT
if(next_expert!=routeReference(features(s,o,p,build,bytes)))throw std::runtime_error("route feature mismatch");
#endif
selected_expert_=next_expert;++inferences_;}
        ++choices_;
    }
    struct Victim { int o,p,id; int64_t bytes; double value,key; };
    struct Ghost { uint64_t at=0; int rule=-1; bool credited=false; int requester=-1; bool avoidable_cross=false; };
    int flags_,rule_=4,options_;
    uint64_t load_demands_=0,compensated_misses_=0;
    bool spilled_=false,first_miss_=false;
    std::array<uint64_t,512> last_{};
    std::array<float,512> heat_{};
    std::array<Ghost,512> ghost_{};
    std::array<double,8> op_heat_{},budget_{};
    std::array<uint64_t,8> op_last_{};
    std::array<double,7> loss_{};
    std::array<unsigned,7> trials_{};
    std::array<double,64> interference_{};
    std::array<uint64_t,64> interference_at_{};
    double interference(int source,int victim,uint64_t now) const {
        int i=source*8+victim;uint64_t age=now>interference_at_[i]?now-interference_at_[i]:0;
        return interference_[i]/(1.0+double(age)/256.0);
    }

    uint64_t epoch_=0,epoch_miss_=0,switched_at_=0,returns_=0,return_base_=0;
    int phase_mask_=-1;
    static uint64_t tick(const SystemState& s) {return uint64_t(s.hit_count+s.miss_count);}
    static bool probeNext(const SystemState& s) {return s.next_op.type=="PROBE";}
    static bool less(const Victim& a,const Victim& b) {
        if(a.key!=b.key)return a.key<b.key;
        if(a.bytes!=b.bytes)return a.bytes>b.bytes;
        return a.id>b.id;
    }
    static double clip(double x,double a,double b) {return std::max(a,std::min(b,x));}
    void observe(int id,int o,uint64_t now) {
        if(last_[id]==now)return;
        uint64_t age=now>last_[id]?now-last_[id]:0;
        heat_[id]=float(double(heat_[id])/(1.0+double(age)/64.0)+1.0);last_[id]=now;
        age=now>op_last_[o]?now-op_last_[o]:0;
        op_heat_[o]=op_heat_[o]/(1.0+double(age)/128.0)+1.0;op_last_[o]=now;
    }
    void observeNext(const SystemState& s) {
        if(!probeNext(s))return;
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
        if(s.operators[o].phase==Phase::PROBE){observe(o*s.num_partitions+p,o,tick(s)+1);
            double z=double(s.operators[o].partitions[p].data_size);
            gds_[o*s.num_partitions+p]=gds_clock_+(z/s.write_bandwidth+z/s.read_bandwidth+1.0)/std::max(1.0,z);}

    }
    void credit(int rule,double loss) {
        if(rule<0)return;
        loss_[rule]=trials_[rule]?0.875*loss_[rule]+0.125*loss:loss;
        ++trials_[rule];
    }
    void loaded(const SystemState& s,int o,int p) {
        int gid=o*s.num_partitions+p;double gs=double(s.operators[o].partitions[p].data_size);
        gds_[gid]=gds_clock_+(gs/s.write_bandwidth+gs/s.read_bandwidth+1.0)/std::max(1.0,gs);
        Ghost& g=ghost_[gid];
        if(!g.at)return;
        uint64_t age=tick(s)+1-g.at,width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        if(age<=width){if(g.rule>=0 || !(flags_&64))++returns_;if(!g.credited)credit(g.rule,1.0);}
        else if(!g.credited)credit(g.rule,0.0);
        if((flags_&1024)&&age<=width&&g.avoidable_cross) {
            int edge=g.requester*8+o;
            double bytes=double(s.operators[o].partitions[p].data_size);
            interference_[edge]=interference(g.requester,o,tick(s))+bytes/s.write_bandwidth+bytes/s.read_bandwidth+1.0;
            interference_at_[edge]=tick(s);++interference_returns;
        }
        g=Ghost();
    }
    void remember(const SystemState& s,const std::vector<Action>& a,int cause) {
        for(const auto& x:a) {
            if(x.type==Action::SPILL) {
                int id=x.op_id*s.num_partitions+x.partition_id;
                if(selected_expert_==5)gds_clock_=std::max(gds_clock_,gds_[id]);
                gds_[id]=0;
                ghost_[id].at=tick(s)+1;
                // If victim and demand target cannot coexist, eviction is forced;
                // do not treat its return as evidence against a discretionary rule.
                ghost_[id].rule=((flags_&64)&&cause>=0&&s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_>s.memory_limit)?-1:cause;
                ghost_[id].credited=false;ghost_[id].requester=requester_;
                ghost_[id].avoidable_cross=requester_>=0&&requester_!=x.op_id&&s.operators[x.op_id].phase==Phase::PROBE&&
                    s.operators[x.op_id].partitions[x.partition_id].data_size+demand_size_<=s.memory_limit;
                if(x.op_id!=requester_)++cross_spills;
            } else loaded(s,x.op_id,x.partition_id);
        }
    }
    int requester_=-1;int64_t demand_size_=0;
    void allocate(const SystemState& s) {
        int k=int(s.operators.size());uint64_t now=tick(s);
        std::array<double,8> cap{},w{};std::array<bool,8> done{};
        for(const auto& op:s.operators) {
            for(const auto& x:op.partitions)cap[op.op_id]+=double(x.data_size);
            int o=op.op_id;uint64_t age=now>op_last_[o]?now-op_last_[o]:0;
            double h=op_heat_[o]/(1.0+double(age)/128.0);
            w[o]=(op.phase==Phase::PROBE?1.0:0.25)*(1.0+h);budget_[o]=0;
        }
        double remaining=double(s.memory_limit);
        for(int pass=0;pass<=k;++pass) {
            double sw=0;for(int o=0;o<k;++o)if(!done[o])sw+=w[o];
            if(sw<=0)break;
            bool capped=false;
            for(int o=0;o<k;++o)if(!done[o] && cap[o]<=remaining*w[o]/sw) {
                budget_[o]=cap[o];done[o]=true;capped=true;
            }
            if(!capped){for(int o=0;o<k;++o)if(!done[o])budget_[o]=remaining*w[o]/sw;break;}
            remaining=double(s.memory_limit);for(int o=0;o<k;++o)if(done[o])remaining-=budget_[o];
        }
        ++allocations;
    }
    void adapt(const SystemState& s,int o,int p) {
        uint64_t now=tick(s);int mask=phase_mask_;
        if(mask!=((1<<int(s.operators.size()))-1)){mask=0;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)mask|=1<<op.op_id;}
        uint64_t observed_misses=(options_&8)?((options_&64)?uint64_t(s.miss_count)+compensated_misses_:load_demands_):uint64_t(s.miss_count);
        bool first=!first_miss_,urgent=returns_-return_base_>=3;
        if(!first && mask==phase_mask_ && now-epoch_<128 && observed_misses-epoch_miss_<32 && !urgent)return;
        uint64_t width=uint64_t(std::max(64,int(s.operators.size())*s.num_partitions*2));
        for(int i=0,q=int(s.operators.size())*s.num_partitions;i<q;++i){auto& g=ghost_[i];if(g.at && !g.credited && now+1-g.at>width){credit(g.rule,0.0);g.credited=true;}}
        if(first) {
            first_miss_=true;
            if(flags_&32) {
                double a=double(s.operators[o].partitions[p].data_size)/s.memory_limit,b=-1;
                if(probeNext(s))b=double(s.operators[s.next_op.op_id].partitions[int(s.next_op.key%s.num_partitions)].data_size)/s.memory_limit;
                rule_=a<=.125?(b<=.0013453512706539845?3:4):(s.operators.size()<=1?4:3);
            }
        } else if(flags_&4) {
            double rate=std::min(1.0,double(observed_misses-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_)));
            int desired=(flags_&256)?rule_:4;
            // Positive evidence for a repeat working set favours heat/byte;
            // sustained misses without quick returns favour observed recency.
            if(urgent && rate>.12)desired=6;
            else if(rate>.65 && !urgent && !(flags_&128))desired=3;
            if((flags_&256)&&desired==rule_&&rule_!=4&&rate>.30&&loss_[rule_]>.50)desired=4;
            double best=loss_[desired]+(trials_[desired]?0.0:.12);
            for(int r:{4,3,6})if(trials_[r]>=4 && loss_[r]+.12<best){desired=r;best=loss_[r];}
            uint64_t dwell=urgent?8:64;
            if(desired!=rule_ && now-switched_at_>=dwell) {
                // Hysteresis prevents a tiny sampled advantage triggering a switch.
                if(urgent || desired==4 || !trials_[rule_] || loss_[rule_]>best+.08 || rate>.65) {
                    rule_=desired;switched_at_=now;++switches;
                }
            }
        }
        epoch_=now;epoch_miss_=observed_misses;return_base_=returns_;phase_mask_=mask;++epochs;
        if(flags_&8)allocate(s);
    }
    std::vector<Action> plan(const SystemState& s,int64_t need,int to,int tp,bool build,int po=-1,int pp=-1) {
        int64_t deficit=need-(s.memory_limit-s.memory_used);if(deficit<=0)return {};
        int rule=activeRule(build);
        std::array<double,8> used{},factor{};factor.fill(1.0);
        bool quota=(selected_expert_==6||selected_expert_==7);
        if(build&&(options_&4)){bool has_probe=false;for(const auto& op:s.operators)if(op.phase==Phase::PROBE)has_probe=true;if(!has_probe)quota=false;}
        if(quota) {
            if(build || !allocations)allocate(s);
            for(const auto& op:s.operators)for(const auto& x:op.partitions)if(x.in_memory)used[op.op_id]+=double(x.data_size);
            double pad=double(s.memory_limit)/(32.0*s.operators.size());
            for(unsigned o=0;o<s.operators.size();++o)factor[o]=clip((budget_[o]+pad)/(used[o]+pad),.5,2.0);
        }
        std::array<Victim,512> c;int n=0,best=-1;uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            int o=op.op_id,p=x.partition_id,id=o*s.num_partitions+p;
            if(!x.in_memory||x.data_size<=0||(o==to&&p==tp)||(o==po&&p==pp))continue;
            double v=0,key=-double(x.data_size)/factor[o];
            if(rule==8){v=double(x.data_size)/s.write_bandwidth;key=double(x.data_size);}
            else if(rule==9){
                if(gds_[id]==0)gds_[id]=gds_clock_+(double(x.data_size)/s.write_bandwidth+double(x.data_size)/s.read_bandwidth+1.0)/double(x.data_size);
                key=gds_[id];
            }
            else if(rule==4) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0),q=.15+.70*h/(1.0+h);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)q=1.0;
                if(op.phase==Phase::BUILD)q*=.35;
                v=(double(x.data_size)/s.write_bandwidth+q*(double(x.data_size)/s.read_bandwidth+32.0))*factor[o];
                key=v/double(x.data_size);
            } else if(rule==3)key=(double(last_[id])+1.0)*factor[o];
            else if(rule==6) {
                uint64_t age=now>last_[id]?now-last_[id]:0;
                double h=double(heat_[id])/(1.0+double(age)/64.0);
                key=(1.0+h)*factor[o]/double(x.data_size);
                if(probeNext(s)&&s.next_op.op_id==o&&s.next_op.key%s.num_partitions==p)key*=16.0;
            }
            if((flags_&1024)&&requester_>=0&&requester_!=o) {
                double unit=double(s.memory_limit)*(1.0/s.write_bandwidth+1.0/s.read_bandwidth)+1.0;
                double charge=1.0+std::min(3.0,interference(requester_,o,now)/unit);
                if(rule==0)key/=charge;else {key*=charge;v*=charge;}
            }
            c[n]={o,p,id,x.data_size,v,key};if(best<0||less(c[n],c[best]))best=n;++n;
        }
        // Every resident x with size(x)>M-locked is infeasible beside the
        // partitions which this request must retain. Such x must be spilled.
        // If forced victims cover the deficit, this set attains the unavoidable
        // immediate-write lower bound. No future-Score optimality is claimed.
        int64_t locked=build?s.operators[to].partitions[tp].data_size+need:need;
        if(po>=0&&!(po==to&&pp==tp)&&s.operators[po].partitions[pp].in_memory)
            locked+=s.operators[po].partitions[pp].data_size;
        if(locked<=s.memory_limit){
            int64_t forced_bytes=0;
            for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)forced_bytes+=c[i].bytes;
            if(forced_bytes>=deficit){
                std::vector<Action> a;a.reserve(n+2);
                for(int i=0;i<n;++i)if(c[i].bytes>s.memory_limit-locked)a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                return a;
            }
        }
        // Exact minimum immediate write bytes for <=10 eligible candidates.
        // Larger instances use size order + covering singleton, without an optimality claim.
        if(rule==8&&n<=10){
            int64_t best_bytes=INT64_MAX;unsigned best_mask=0;
            std::array<int64_t,1024> sums;sums[0]=0;unsigned count=1;
            for(int i=0;i<n;++i){
                for(unsigned j=0;j<count;++j){unsigned mask=count+j;sums[mask]=sums[j]+c[i].bytes;
                    if(sums[mask]>=deficit&&sums[mask]<best_bytes){best_bytes=sums[mask];best_mask=mask;}}
                count*=2;
            }
            std::vector<Action> a;a.reserve(n+2);
            for(int i=0;i<n;++i)if(best_mask&(1u<<i))a.emplace_back(Action::SPILL,c[i].o,c[i].p);
            return a;
        }
        // The sorted greedy prefix has length one in this case. Select the
        // same minimum-cost covering singleton in O(Q), preserving tie order.
        if((flags_&16) && best>=0 && c[best].bytes>=deficit) {
            int chosen=best;
            if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit &&
                (c[i].value<c[chosen].value || (c[i].value==c[chosen].value&&less(c[i],c[chosen]))))chosen=i;
            ++linear_plans;std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[chosen].o,c[chosen].p);return a;
        }
        // Exact shortcut for a sorted greedy prefix of length two.
        // No heuristic truncation: all covering singletons are still compared.
        if(best>=0&&c[best].bytes<deficit) {
            int second=-1;
            for(int i=0;i<n;++i)if(i!=best&&(second<0||less(c[i],c[second])))second=i;
            if(second>=0&&c[best].bytes+c[second].bytes>=deficit) {
                int64_t freed=c[best].bytes+c[second].bytes;
                double value=c[best].value+c[second].value;int single=-1;
                if(rule==4||rule==8)for(int i=0;i<n;++i)if(c[i].bytes>=deficit) {
                    if(c[i].value<value){single=i;value=c[i].value;}
                    else if(single>=0&&c[i].value==value&&less(c[i],c[single]))single=i;
                }
                std::vector<Action> a;a.reserve(2+(build?0:2));
                if(single>=0)a.emplace_back(Action::SPILL,c[single].o,c[single].p);
                else {
                    for(int i:{best,second}) {
                        if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
                        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
                    }
                }
                ++prefix2_plans;return a;
            }
        }
        ++sorted_plans;std::sort(c.begin(),c.begin()+n,less);
        int take=0;int64_t freed=0;double value=0;
        while(take<n&&freed<deficit){freed+=c[take].bytes;value+=c[take].value;++take;}
        if(rule==4||rule==8) {
            int single=-1;for(int i=0;i<n;++i)if(c[i].bytes>=deficit&&c[i].value<value){single=i;value=c[i].value;}
            if(single>=0){std::vector<Action> a;a.reserve(build?1:3);a.emplace_back(Action::SPILL,c[single].o,c[single].p);return a;}
        }
        std::vector<Action> a;a.reserve(take+(build?0:2));
        for(int i=0;i<take;++i)if((rule==4||rule==8)&&freed-c[i].bytes>=deficit)freed-=c[i].bytes;
        else a.emplace_back(Action::SPILL,c[i].o,c[i].p);
        return a;
    }
    static int64_t written(const SystemState& s,const std::vector<Action>& a) {
        int64_t n=0;for(const auto& x:a)if(x.type==Action::SPILL)n+=s.operators[x.op_id].partitions[x.partition_id].data_size;return n;
    }
    // Local certificate: any resident x with size(x)>M-size(B) MUST leave
    // before B can be loaded. Only prefetch when these forced victims suffice.
    bool forced(const SystemState& s,int o,int p,int64_t need,std::vector<Action>& a,int64_t freed) {
        if(!(flags_&2)||need<s.memory_limit/2)return false;
        int64_t deficit=need-(s.memory_limit-s.memory_used+freed);if(deficit<=0)return true;
        std::array<bool,512> removed{};
        for(const auto& x:a)if(x.type==Action::SPILL)removed[x.op_id*s.num_partitions+x.partition_id]=true;
        std::vector<Action> extra;int64_t sum=0;
        for(const auto& op:s.operators)for(const auto& x:op.partitions) {
            if(x.in_memory&&x.data_size>s.memory_limit-need&&!removed[op.op_id*s.num_partitions+x.partition_id]&&!(op.op_id==o&&x.partition_id==p)) {
                extra.emplace_back(Action::SPILL,op.op_id,x.partition_id);sum+=x.data_size;
            }
        }
        if(sum<deficit)return false;
        a.insert(a.end(),extra.begin(),extra.end());++certified_prefetches;return true;
    }
public:

    void forceNext(int x){forced_next_=x;}
    void setMode(int x){policy_mode_=x;}
    int lastExpert() const{return selected_expert_;}
    uint64_t inferenceCount() const{return inferences_;}
    std::array<float,32> features(const SystemState& s,int o,int p,bool build,int64_t bytes) const {
        std::array<float,32> f{};double m=double(s.memory_limit),sum=0,sq=0,mx=0,mn=m,bld=0,prb=0,own=0,total=0,own_total=0,heat=0;int nr=0;
        uint64_t now=tick(s);
        for(const auto& op:s.operators)for(const auto& x:op.partitions){
            total+=x.data_size;if(op.op_id==o)own_total+=x.data_size;
            if(!x.in_memory||x.data_size<=0)continue;
            double z=double(x.data_size);sum+=z;sq+=z*z;mx=std::max(mx,z);mn=std::min(mn,z);++nr;
            if(op.phase==Phase::BUILD)bld+=z;else prb+=z;if(op.op_id==o)own+=z;
            int id=op.op_id*s.num_partitions+x.partition_id;uint64_t age=now>last_[id]?now-last_[id]:0;
            heat+=double(heat_[id])/(1.0+double(age)/64.0);
        }
        double free=double(s.memory_limit-s.memory_used),size=double(bytes),q=double(s.operators.size()*s.num_partitions);
        const auto& target=s.operators[o].partitions[p];int tid=o*s.num_partitions+p;uint64_t age=now>last_[tid]?now-last_[tid]:0;
        double h=double(heat_[tid])/(1.0+double(age)/64.0),avg=heat/std::max(1,nr);
        f[0]=float(s.memory_used/m);f[1]=float(size/m);f[2]=float(std::max(0.0,size-free)/m);f[3]=float(free/m);
        f[4]=float(s.operators.size()/8.0);f[5]=float(s.num_partitions/64.0);f[6]=float(build);f[7]=float(s.operators[o].phase==Phase::PROBE);
        f[8]=float(nr/q);f[9]=float(mx/m);f[10]=nr?float(mn/m):0;f[11]=float(sum/std::max(1,nr)/m);
        f[12]=float(sq/(sum*sum+1.0));f[13]=float(bld/m);f[14]=float(prb/m);f[15]=float(own/m);f[16]=float(bounded(own_total/(8*m)));
        bool pn=s.next_op.type=="PROBE",in=s.next_op.type=="INSERT";f[17]=float(pn);f[18]=float(in);
        if(pn||in){int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& nx=s.operators[no].partitions[np];
            f[19]=float(nx.data_size/m);f[20]=float(nx.in_memory);f[21]=float(no==o);f[22]=float((build?target.data_size+size:size)+nx.data_size<=m);}
        f[23]=float(s.write_bandwidth/10000.0);f[24]=float(s.read_bandwidth/10000.0);
        f[25]=float(double(s.miss_count)/double(std::max(uint64_t(1),now)));
        f[26]=float(bounded(double(uint64_t(s.miss_count)+compensated_misses_-epoch_miss_)/double(std::max(uint64_t(1),now-epoch_))));
        f[27]=float(h/(1+h));f[28]=float(avg/(1+avg));f[29]=float(bounded(double(returns_-return_base_)/double(std::max(uint64_t(1),now-epoch_))));
        f[30]=float(selected_expert_/7.0);f[31]=float(total/(m*q));return f;
    }
    uint64_t joint_loads=0,joint_rejections=0,prefix2_plans=0;
    uint64_t interference_returns=0;
    void externalSpill(){spilled_=true;}
    uint64_t switches=0,epochs=0,allocations=0,cross_spills=0,linear_plans=0,sorted_plans=0,advanced_builds=0,certified_prefetches=0;
    explicit MySpillScheduler(int mode=-1):policy_mode_(mode),flags_(351),options_(105){}
    int selectedMode() const {return rule_;}
    std::vector<Action> onMemoryOverflow(const SystemState& s,int o,int p,int64_t bytes) override {
        choose(s,o,p,true,bytes);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+bytes;auto a=plan(s,bytes,o,p,true);spilled_=true;remember(s,a,-1);return a;
    }
    std::vector<Action> onPartitionMiss(const SystemState& s,int o,int p) override {
        choose(s,o,p,false,s.operators[o].partitions[p].data_size);requester_=o;++load_demands_;loaded(s,o,p);adapt(s,o,p);observe(o*s.num_partitions+p,o,tick(s));observeNext(s);
        int64_t size=s.operators[o].partitions[p].data_size;demand_size_=size;
        if((options_&1)&&probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            int64_t limit=(options_&2)?s.memory_limit/2:((options_&16)?s.memory_limit*3/4:s.memory_limit);
            if(s.operators[no].phase==Phase::PROBE&&!b.in_memory&&!(no==o&&np==p)&&size+b.data_size<=limit&&
                (!(options_&64)||(activeRule(false)==6&&size+b.data_size<=s.memory_limit/2&&std::max(size,b.data_size)<=2*std::min(size,b.data_size)))) {
                auto a=plan(s,size+b.data_size,o,p,false);
                bool accept=true;
                int64_t tolerance=std::max(int64_t(16),(size+b.data_size)/256),sum=0;
                if(options_&(32|64))for(const auto& v:a){
                    int64_t bytes=s.operators[v.op_id].partitions[v.partition_id].data_size;sum+=bytes;
                    if(bytes>((options_&64)?std::max(size,b.data_size)+tolerance:size+b.data_size))accept=false;
                }
                if((options_&64)&&sum>size+b.data_size+tolerance)accept=false;
                if(accept){
                    if(options_&64){
                        int64_t prefix=0,needed=size-(s.memory_limit-s.memory_used);
                        for(const auto& v:a){if(prefix>=needed)break;prefix+=s.operators[v.op_id].partitions[v.partition_id].data_size;}
                        if(s.memory_limit-s.memory_used+prefix<size+b.data_size)++compensated_misses_;
                    }
                    if(a.capacity()<a.size()+2)a.reserve(a.size()+2);
                    a.emplace_back(Action::LOAD,no,np);a.emplace_back(Action::LOAD,o,p);
                    ++load_demands_;++joint_loads;demand_size_=size+b.data_size;remember(s,a,creditRule());return a;
                }
                ++joint_rejections;
            }
        }
        auto a=plan(s,size,o,p,false);if(a.capacity()<a.size()+2)a.reserve(a.size()+2);int64_t freed=written(s,a);
        if(probeNext(s)) {
            int no=s.next_op.op_id,np=int(s.next_op.key%s.num_partitions);const auto& b=s.operators[no].partitions[np];
            if(s.operators[no].phase==Phase::PROBE&&!(no==o&&np==p)&&size+b.data_size<=s.memory_limit) {
                bool evicts=false;for(const auto& x:a)if(x.op_id==no&&x.partition_id==np)evicts=true;
                if(b.in_memory&&evicts) {
                    auto other=plan(s,size,o,p,false,no,np);int64_t f=written(s,other);
                    if(double(f-freed)/s.write_bandwidth<=double(b.data_size)/s.read_bandwidth+1.0){a.swap(other);freed=f;}
                }
                // Forced-victim prefetch is used at periodic callbacks only.
                // Here the existing no-extra-spill joint load remains cheaper.
                if(!b.in_memory&&s.memory_used-freed+size+b.data_size<=s.memory_limit){a.emplace_back(Action::LOAD,no,np);++load_demands_;}
            }
        }
        a.emplace_back(Action::LOAD,o,p);remember(s,a,creditRule());return a;
    }
    std::vector<Action> onPeriodicAdjust(const SystemState& s) override {
        if((flags_&1)&&s.next_op.type=="INSERT") {
            int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);
            if(s.operators[o].partitions[p].in_memory&&s.next_op.tuple_size>s.memory_limit-s.memory_used) {
                choose(s,o,p,true,s.next_op.tuple_size);requester_=o;demand_size_=s.operators[o].partitions[p].data_size+s.next_op.tuple_size;
                // PERIODIC_ADMISSION_V1: fixed next INSERT, immediate writes only.
                const int64_t admission_size=s.operators[o].partitions[p].data_size;
                const int64_t admission_tuple=s.next_op.tuple_size;
                const int64_t admission_factor=int64_t(1)<<2;
                if(admission_size>0&&admission_tuple>0&&admission_tuple<=s.memory_limit&&
                   admission_size<=s.memory_limit-admission_tuple) {
                    const int64_t admission_full=admission_size+admission_tuple;
                    if(admission_full<=s.memory_limit/admission_factor) {
                        const int64_t admission_cutoff=admission_full*admission_factor;
                        bool admission_has_other=false,admission_certified=true;
                        for(const auto& admission_op:s.operators) {
                            for(const auto& admission_part:admission_op.partitions) {
                                if(!admission_part.in_memory||admission_part.data_size<=0||
                                   (admission_op.op_id==o&&admission_part.partition_id==p))continue;
                                admission_has_other=true;
                                if(admission_part.data_size<admission_cutoff) {
                                    admission_certified=false;break;
                                }
                            }
                            if(!admission_certified)break;
                        }
                        if(admission_has_other&&admission_certified) {
                            std::vector<Action> admission_actions;admission_actions.reserve(1);
                            admission_actions.emplace_back(Action::SPILL,o,p);
                            spilled_=true;remember(s,admission_actions,-1);++advanced_builds;return admission_actions;
                        }
                    }
                }
                auto a=plan(s,s.next_op.tuple_size,o,p,true);spilled_=true;remember(s,a,-1);++advanced_builds;return a;
            }
            return {};
        }
        if(!spilled_||!probeNext(s))return {};
        int o=s.next_op.op_id,p=int(s.next_op.key%s.num_partitions);const auto& x=s.operators[o].partitions[p];
        if(s.operators[o].phase!=Phase::PROBE)return {};
        observe(o*s.num_partitions+p,o,tick(s)+1);
        if(x.in_memory)return {};
        requester_=o;demand_size_=x.data_size;std::vector<Action> a;
        if(x.data_size<=s.memory_limit-s.memory_used||forced(s,o,p,x.data_size,a,0)) {
            ++load_demands_;a.emplace_back(Action::LOAD,o,p);remember(s,a,-1);return a;
        }
        return {};
    }
};
